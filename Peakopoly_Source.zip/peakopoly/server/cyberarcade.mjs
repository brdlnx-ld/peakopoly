// New arcade: only moves and choices arrive from the browser.
export const cyberLaunch=Date.parse('2026-11-30T00:00:00Z');
export const cyberKinds=['parcel','memory','deal'];
export function cyberStart(g,now,rng){
 if(g.kind==='parcel')Object.assign(g,{round:1,correct:0,lives:3,lane:rng(3),started:now,due:now+12000});
 if(g.kind==='memory')Object.assign(g,{round:1,pattern:Array.from({length:3},()=>rng(4)),stage:'watch',revealUntil:now+3500,cursor:0,completed:0});
 if(g.kind==='deal'){
  const values=[0,5,10,25,40,60];for(let i=5;i>0;i--){const j=rng(i+1);[values[i],values[j]]=[values[j],values[i]];}
  Object.assign(g,{boxes:values,opened:[],selected:null,stage:'pick',offer:0});
 }
}
export function cyberPrize(g){return g.kind==='parcel'?Math.min(60,g.correct*3):g.kind==='memory'?Math.min(60,g.completed*10):0;}
export function cyberMove(g,a,action,now,rng,finish){
 if(action==='mini_collect'){
  if(g.kind==='deal')throw Error('Accept the offer or open your final cage');
  finish(cyberPrize(g));return;
 }
 if(g.kind==='parcel'){
  if(action!=='mini_sort'||!Number.isInteger(a.lane)||a.lane<0||a.lane>2)throw Error('Choose a destination lane');
  const correct=now<=g.due&&a.lane===g.lane;
  g.seq++;if(correct)g.correct++;else g.lives--;
  if(!g.lives||g.round>=20){finish(cyberPrize(g));return;}
  g.round++;g.lane=rng(3);g.started=now;g.due=now+Math.max(6000,12000-g.round*250);g.feedback=correct?'Correct destination':'Mis-sort or timed out';
  return;
 }
 if(g.kind==='memory'){
  if(action==='mini_recall'){
   if(g.stage!=='watch'||now<g.revealUntil)throw Error('Watch the complete sequence first');
   g.stage='recall';g.seq++;return;
  }
  if(action!=='mini_memory'||g.stage!=='recall'||!Number.isInteger(a.pad)||a.pad<0||a.pad>3)throw Error('Wait for your turn, then tap a scanner pad');
  g.seq++;
  if(a.pad!==g.pattern[g.cursor]){finish(cyberPrize(g));return;}
  g.cursor++;
  if(g.cursor===g.pattern.length){
   g.completed++;if(g.completed===6){finish(60);return;}
   g.round++;g.pattern.push(rng(4));g.stage='watch';g.cursor=0;g.revealUntil=now+g.pattern.length*800+1100;
  }
  return;
 }
 if(action!=='mini_cage'||!Number.isInteger(a.box)||a.box<0||a.box>5)throw Error('Choose a cage');
 if(g.stage==='pick'){g.selected=a.box;g.stage='reveal';g.seq++;return;}
 if(g.stage==='final'){
  if(a.box!==g.selected&&!g.opened.some(x=>x.box===a.box)){g.selected=a.box;}
  else if(a.box!==g.selected)throw Error('This cage is already open');
  finish(g.boxes[g.selected]);return;
 }
 if(g.stage==='offer'){
  if(a.choice==='take'){finish(g.offer);return;}
  if(a.choice!=='risk')throw Error('Choose deal or disaster');
  g.stage=g.opened.length===4?'final':'reveal';g.seq++;return;
 }
 if(g.stage!=='reveal'||a.box===g.selected||g.opened.some(x=>x.box===a.box))throw Error('Open an unselected cage');
 g.opened.push({box:a.box,value:g.boxes[a.box]});g.seq++;
 if(g.opened.length===2||g.opened.length===4){
  const left=g.boxes.filter((_,i)=>!g.opened.some(x=>x.box===i));
  g.offer=Math.floor(left.reduce((n,v)=>n+v,0)/left.length*0.8);g.stage='offer';
 }
}
export function cyberPublic(mini){
 const g=mini?.session;if(!g)return;
 if(g.kind==='deal')delete g.boxes;
 if(g.kind==='memory'&&g.stage!=='watch')delete g.pattern;
}
