// New arcade: only moves and choices arrive from the browser.
export const cyberLaunch=Date.parse('2026-11-30T00:00:00Z');
export const cyberKinds=['parcel','memory','deal'];
export function cyberStart(g,now,rng){
 if(g.kind==='parcel'){
  const shipments=Array.from({length:20},(_,i)=>({id:i+1,lane:rng(3),started:now+i*1300,due:now+i*1300+Math.max(3000,5500-i*125)}));
  Object.assign(g,{round:1,correct:0,lives:3,shipments,lane:shipments[0].lane,started:now,due:shipments[0].due});
 }
 if(g.kind==='memory')Object.assign(g,{round:1,pattern:Array.from({length:3},()=>rng(4)),stage:'watch',revealUntil:now+3500,cursor:0,completed:0});
 if(g.kind==='deal'){
  const values=[0,25,75,150,300,500];for(let i=5;i>0;i--){const j=rng(i+1);[values[i],values[j]]=[values[j],values[i]];}
  Object.assign(g,{boxes:values,opened:[],selected:null,stage:'pick',offer:0});
 }
}
export function cyberPrize(g){return g.kind==='parcel'?Math.min(60,g.correct*3):g.kind==='memory'?Math.min(60,g.completed*10):0;}
export function cyberMove(g,a,action,now,rng,finish){
 if(action==='mini_collect'){
  if(g.kind==='deal')throw Error('Accept the offer or open your final box');
  finish(cyberPrize(g));return;
 }
 if(g.kind==='parcel'){
  // An already-running legacy attempt upgrades to a proper shared belt.
  if(!g.shipments)g.shipments=[{id:g.round,lane:g.lane,started:g.started,due:g.due}];
  const head=g.shipments[0];
  if(action==='mini_timeout'){
   if(now<head.due)throw Error('The shipment has not timed out');
   while(g.shipments.length&&g.shipments[0].due<=now){g.shipments.shift();g.lives--;}
   g.feedback='Shipment missed the sorter';
  }else{
   if(action!=='mini_sort'||!Number.isInteger(a.lane)||a.lane<0||a.lane>2)throw Error('Choose a destination lane');
   if(now<head.started)throw Error('Wait for the next shipment');
   const correct=now<=head.due&&a.lane===head.lane;
   g.shipments.shift();if(correct)g.correct++;else g.lives--;
   g.feedback=correct?'Correct destination':'Mis-sort or timed out';
  }
  g.seq++;
  if(g.lives<=0||!g.shipments.length){finish(cyberPrize(g));return;}
  const next=g.shipments[0];Object.assign(g,{round:next.id,lane:next.lane,started:next.started,due:next.due});
  return;
 }
 if(g.kind==='memory'){
  if(action==='mini_recall'){
   if(g.stage!=='watch'||now<g.revealUntil)throw Error('Watch the complete sequence first');
   g.stage='recall';g.seq++;return;
  }
  if(action!=='mini_memory'||g.stage!=='recall'||!Number.isInteger(a.pad)||a.pad<0||a.pad>3)throw Error('Wait for your turn, then tap a scanner pad');
  g.seq++;
  if(a.pad!==g.pattern[g.cursor]){finish(cyberPrize(g));return;}
  g.cursor++;
  if(g.cursor===g.pattern.length){
   g.completed++;if(g.completed===6){finish(60);return;}
   g.round++;g.pattern.push(rng(4));g.stage='watch';g.cursor=0;g.revealUntil=now+g.pattern.length*800+1100;
  }
  return;
 }
 if(action!=='mini_cage'||!Number.isInteger(a.box)||a.box<0||a.box>5)throw Error('Choose a box');
 if(g.stage==='pick'){g.selected=a.box;g.stage='reveal';g.seq++;return;}
 if(g.stage==='final'){
  if(a.box!==g.selected&&!g.opened.some(x=>x.box===a.box)){g.selected=a.box;}
  else if(a.box!==g.selected)throw Error('This box is already open');
  finish(g.boxes[g.selected]);return;
 }
 if(g.stage==='offer'){
  if(a.choice==='take'){finish(g.offer);return;}
  if(a.choice!=='risk')throw Error('Choose deal or disaster');
  g.stage=g.opened.length===4?'final':'reveal';g.seq++;return;
 }
 if(g.stage!=='reveal'||a.box===g.selected||g.opened.some(x=>x.box===a.box))throw Error('Open an unselected box');
 g.opened.push({box:a.box,value:g.boxes[a.box]});g.seq++;
 if(g.opened.length===2||g.opened.length===4){
  const left=g.boxes.filter((_,i)=>!g.opened.some(x=>x.box===i));
  g.offer=Math.floor(left.reduce((n,v)=>n+v,0)/left.length*0.8);g.stage='offer';
 }
}
export function cyberPublic(mini){
 const g=mini?.session;if(!g)return;
 if(g.kind==='deal'){g.values=[...g.boxes].sort((a,b)=>a-b);delete g.boxes;}
 if(g.kind==='memory'&&g.stage!=='watch')delete g.pattern;
}
