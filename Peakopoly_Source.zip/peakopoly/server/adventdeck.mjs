// A fixed catalogue of unique effects. Player assignments are never sent to clients.
export const adventStart=Date.parse('2026-12-01T00:00:00Z');
export const closingStart=Date.parse('2026-12-23T00:00:00Z');
export const adventEnd=Date.parse('2026-12-24T19:00:00Z');
export const adventCards=[];
const add=(family,n,title,text,effect,closing=false)=>adventCards.push({id:family+'-'+String(n+1).padStart(2,'0'),family,title,text,effect,closing});
const kinds=['location','role','any'],kindName=k=>k==='any'?'asset':k==='role'?'role licence':'location';
const selectors=['highest','lowest','random'];
for(let i=0;i<26;i++){
 const n=i+1,k=kinds[i%3],pick=selectors[Math.floor(i/3)%3],fallback=75+5*i;
 add('windfall',i,'Finance Error '+n,'Collect £'+(100+i*20)+(i%3?' and '+(i%3)+' bonus roll(s).':'.'),{type:'grant',cash:100+i*20,rolls:i%3});
 add('invoice',i,'Christmas Invoice '+n,'Pay '+(10+i)+'% of your cash, capped at £'+(75+i*10)+'. Receive '+(1+i%3)+' bonus roll(s).',{type:'tax',percent:10+i,cap:75+i*10,rolls:1+i%3});
 add('collection',i,'Robin Hood Collection '+n,'Collect up to £'+(20+i*5)+' from each active player with '+(i%2?'more assets':'higher net worth')+' than you. If nobody qualifies, collect £'+fallback+' from the bank.',{type:'collect',amount:20+i*5,comparison:i%2?'assets':'worth',fallback});
 add('claim',i,'Unclaimed Stock '+n,'Claim one random unowned '+kindName(k)+' priced at no more than £'+(100+i*20)+'. If none qualifies, collect £'+fallback+'.',{type:'claim',kind:k,limit:100+i*20,fallback});
 add('sale',i,'Compulsory Sale '+n,'Return your '+pick+' '+kindName(k)+' to the bank for '+(50+(i%4)*50)+'% of its original price. Upgrades are removed. If none qualifies, pay up to £'+(25+i*5)+'.',{type:'sale',kind:k,pick,percent:50+(i%4)*50,fallback:25+i*5});
 add('theft',i,'Hostile Christmas '+n,'Take the '+pick+' '+kindName(k)+' from an active player '+(i%2?'with more assets':'with higher net worth')+' than you. Upgrades travel with it. If no target qualifies, collect £'+fallback+'.',{type:'steal',kind:k,pick,comparison:i%2?'assets':'worth',fallback});
 add('swap',i,'Secret Santa Swap '+n,'Swap your '+pick+' '+kindName(k)+' for a random '+kindName(k)+' owned by a richer active player. Upgrades travel with each asset. If a swap is impossible, collect £'+fallback+'.',{type:'swap',kind:k,pick,fallback});
 add('rolls',i,'Overtime Envelope '+n,'Receive '+(2+i%12)+' bonus rolls and '+(i<13?'collect £':'pay up to £')+(25+Math.floor(i/2)*10)+'.',{type:'rolls',rolls:2+i%12,cash:(i<13?1:-1)*(25+Math.floor(i/2)*10)});
 add('protection',i,'Bank Cover '+n,'The bank covers fees on your next '+(1+i%8)+' board rolls. Collect £'+(20+i*10)+' too. Protection adds to existing cover and ends at the finale.',{type:'protection',count:1+i%8,cash:20+i*10});
 add('gamble',i,'Questionable Decision '+n,'Take £'+(50+i*5)+' safely, or gamble: 50% chance of collecting £'+(250+i*25)+', otherwise pay up to £'+(50+i*5)+'.',{type:'gamble',safe:50+i*5,win:250+i*25,loss:50+i*5});
 const disaster=i===0?{type:'disaster',mode:'liquidate',fallback:0}:i<7?{type:'disaster',mode:'cash',percent:40+i*10,rolls:i}:i<13?{type:'disaster',mode:'upgrades',levels:1+(i%3),compensation:5*i}:i<19?{type:'disaster',mode:'seize',kind:k,count:1+i%2,pick,fallback:30+i*5}:i<23?{type:'disaster',mode:'rolls',cash:50+i*10}:{type:'disaster',mode:'break',fine:50+(i-23)*50};
 const text=disaster.mode==='liquidate'?'FULL LIQUIDATION: lose all cash, normal and campaign rolls, locations, roles, upgrades, held cards and bank cover. Go to Break. Your account and statistics survive.':
 disaster.mode==='cash'?'Lose '+disaster.percent+'% of your cash. Receive '+disaster.rolls+' bonus rolls.':
 disaster.mode==='upgrades'?'Remove up to '+disaster.levels+' upgrade level(s) from every location you own. Collect £'+disaster.compensation+' compensation.':
 disaster.mode==='seize'?'Return up to '+disaster.count+' of your '+disaster.pick+' '+kindName(k)+'(s) to the bank, without payment. If you own none, pay up to £'+disaster.fallback+'.':
 disaster.mode==='rolls'?'Lose all normal and campaign rolls. Collect £'+disaster.cash+'.':
 'Go to Break without passing Start and pay up to £'+disaster.fine+'.';
 add('disaster',i,i===0?'The Grinch Owns Everything':'Grinch Notice '+n,text,disaster);
}
for(let i=0;i<26;i++){
 const e=i%3===0?{type:'grant',cash:100+i*15,rolls:1+i%4}:i%3===1?{type:'gamble',safe:100+i*5,win:400+i*20,loss:0}:{type:'protection',count:1+i%5,cash:125+i*10};
 const text=e.type==='grant'?'Collect £'+e.cash+' and '+e.rolls+' bonus roll(s).':e.type==='gamble'?'Take £'+e.safe+' safely or try a 50/50 chance at £'+e.win+' or nothing.':'Collect £'+e.cash+'; the bank covers fees on your next '+e.count+' board rolls.';
 add('finale',i,'Last Orders '+(i+1),text,e,true);
}
export const cardById=Object.fromEntries(adventCards.map(c=>[c.id,c]));
