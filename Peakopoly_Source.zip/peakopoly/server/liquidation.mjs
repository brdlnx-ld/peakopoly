export const dealAt=Date.parse('2026-11-27T04:30:00Z');
export const themeEnd=Date.parse('2026-11-28T04:30:00Z');
export const finale=Date.parse('2026-12-24T19:00:00Z');
export const cards=[
 ['You’ve Been Liquidated','Lose all cash, rolls, locations, roles, upgrades and held cards. Go to Break.'],
 ['Friday Night Heist','Lose all cash. Keep your portfolio.'],
 ['Licence to Lose','Return all roles to the bank, or pay £250 if you own none.'],
 ['Condemned by Safety','Lose all upgrades, or your best location if you have none. No locations? Pay £200.'],
 ['Your Shift Is Cancelled','Lose all stored rolls and go to Break.'],
 ['Daylight Robbery','Steal a random asset from the net-worth leader (second place if you lead), or gain £250 if they have none.'],
 ['Hostile Takeover','Buy an owned asset for half its original price, with upgrades. Gain £150 if no target is affordable.'],
 ['Finance Left the Safe Open','Collect £1,000.'],
 ['Overtime Gone Mad','Gain 10 extra rolls, valid for seven days or until the finale.'],
 ['Loot the Clearance Aisle','Pick two unowned assets, or collect £200 for each pick the board cannot supply.'],
 ['Rent? Never Heard of It','The bank pays fees on your next five board rolls.'],
 ['Everybody Pays the Clown','Collect up to £75 from each other active player.'],
 ['The Big Red Button','Take £200, or risk all your cash and your best asset for a 50/50 shot at £1,500.']
];
const eligible=p=>p?.active&&!p.observer;
export function deal(s,now,rng,notify,event){
 if(now>=Date.parse('2026-11-13T00:00:00Z')&&now<dealAt&&s.status==='running'&&!s.campaigns.liquidationAnnounced){
  s.campaigns.liquidationAnnounced=true;
  for(const p of Object.values(s.players).filter(eligible))notify(p,'Black Friday has gone rogue: 13 sealed envelopes on 27 November at 04:30. One can wipe your empire. Your envelope waits until your next visit, up to the finale.',now);
  s.undo=null;
 }
 if(s.campaigns.liquidation||now<dealAt||now>=finale||s.status!=='running')return;
 const people=Object.values(s.players).filter(eligible);
 if(people.length!==cards.length){
  if(s.campaigns.liquidationCount!==people.length){
   s.campaigns.liquidationCount=people.length;
   event(s,null,'Black Friday deal is waiting for exactly 13 active players.',now);
   for(const p of Object.values(s.players).filter(x=>x.active&&x.observer))notify(p,'Black Friday draw blocked: '+people.length+' active players; expected 13.',now);
   s.undo=null;
  }
  return;
 }
 const deck=cards.map((_,i)=>i);
 for(let i=deck.length-1;i>0;i--){const j=rng(i+1);[deck[i],deck[j]]=[deck[j],deck[i]];}
 s.campaigns.liquidation={at:now,entries:Object.fromEntries(people.map((p,i)=>[p.id,{card:deck[i],status:'sealed'}]))};
 for(const p of people)notify(p,'Your sealed Black Friday envelope is ready.',now);
 event(s,null,'Black Friday: 13 sealed envelopes have been dealt.',now);s.undo=null;
}
export function pending(s,p,now){
 const x=s.campaigns?.liquidation?.entries[p?.id];
 return now<finale&&eligible(p)&&x&&x.status!=='done'?x:null;
}
function options(s,p,card,board){
 return board.filter(b=>{const a=s.assets[b.id];return a&&(card===9?!a.owner:a.owner&&a.owner!==p.id&&s.players[a.owner]&&p.cash>=Math.floor(b.price/2));});
}
export function view(s,p,now,board){
 const entries=s.campaigns?.liquidation?.entries||{};
 const x=entries[p?.id],open=x?.status==='choice'&&now<finale;
 return {mine:x?{status:x.status==='done'?'done':now>=finale?'expired':x.status,
   ...(x.status!=='sealed'?{title:cards[x.card][0],description:cards[x.card][1],result:x.result}:{}),
   ...(open?{remaining:x.remaining,options:options(s,p,x.card,board).map(b=>({id:b.id,name:b.name,price:x.card===6?Math.floor(b.price/2):0})),red:x.card===12}:{})}:null,
   results:Object.entries(entries).filter(([,v])=>v.status==='done').map(([id,v])=>({name:s.players[id]?.name,title:cards[v.card][0],result:v.result})),
   blocked:s.campaigns?.liquidationCount!==undefined&&!s.campaigns.liquidation};
}
export function resolve(s,p,action,args,now,rng,h){
 const x=pending(s,p,now);
 if(!x)throw Error('No Black Friday envelope to resolve');
 const i=x.card, {board,money,event,sendBreak,worth,notify}=h;
 const owned=(who)=>board.filter(b=>s.assets[b.id]?.owner===who.id);
 const best=(list)=>[...list].sort((a,b)=>b.price+s.assets[b.id].level*(b.upgrade||0)-a.price-s.assets[a.id].level*(a.upgrade||0)||a.id-b.id)[0];
 const pay=n=>money(s,p,n,now,null,'liquidation');
 const transfer=(b,to)=>{
  const a=s.assets[b.id];a.owner=to?.id||null;if(!to)a.level=0;a.open=false;
  if(to)to.wanted=(to.wanted||[]).filter(id=>id!==b.id);
  for(const t of s.trades)if(t.status==='pending'&&(t.give.includes(b.id)||t.want.includes(b.id))){
   t.status='cancelled';for(const id of [t.from,t.to])if(s.players[id])notify(s.players[id],'Trade cancelled: Black Friday changed ownership of '+b.name+'.',now);
  }
 };
 const loseRolls=()=>{p.rolls=0;p.campaignRolls=[];};
 const finish=result=>{x.status='done';x.result=result;event(s,p,p.name+' opened '+cards[i][0]+' — '+result,now,{kind:'liquidation'});};
 const choices=()=>options(s,p,i,board);
 const settleNoAssets=()=>{if(i===6){pay(150);finish('Collected £150 instead.');}else{const n=200*x.remaining;pay(n);finish((x.picks.length?'Claimed '+x.picks.join(', ')+' and collected ':'Collected ' )+'£'+n+'.');}};
 if(action==='liquidation_choose'){
  if(x.status!=='choice')throw Error('Open the envelope first');
  if(i===12){
   if(!['safe','risk'].includes(args.choice))throw Error('Choose take or risk');
   if(args.choice==='safe'){pay(200);finish('Took £200.');}
   else if(rng(2)===0){pay(1500);finish('Pressed the button and won £1,500.');}
   else{pay(-p.cash);const b=best(owned(p));if(b)transfer(b,null);finish('Lost all cash'+(b?' and '+b.name:'')+'.');}
   return;
  }
  const list=choices();
  if(!list.length){settleNoAssets();return;}
  const b=list.find(b=>b.id===args.asset);if(!b)throw Error('Choose a currently available asset');
  if(i===6){const price=Math.floor(b.price/2);money(s,p,-price,now,s.players[s.assets[b.id].owner],'liquidation');transfer(b,p);finish('Took over '+b.name+' for £'+price+'.');}
  else{transfer(b,p);x.picks.push(b.name);x.remaining--;if(!x.remaining)finish('Claimed '+x.picks.join(' and ')+'.');else if(!choices().length)settleNoAssets();}
  return;
 }
 if(x.status!=='sealed')throw Error('Your card has already been revealed');
 const assets=owned(p);
 switch(i){
  case 0: pay(-p.cash);loseRolls();assets.forEach(b=>transfer(b,null));for(let j=0;j<p.cards;j++)s.discards.training.push(3);p.cards=0;p.campaignShield=0;p.mini&&(p.mini.session=null);sendBreak(s,p,now);finish('Liquidated and sent to Break.');break;
  case 1: pay(-p.cash);finish('Lost all cash.');break;
  case 2:{const roles=assets.filter(b=>b.type==='role');if(roles.length)roles.forEach(b=>transfer(b,null));else pay(-250);finish(roles.length?'Lost '+roles.length+' role licence(s).':'Paid up to £250 instead.');break;}
  case 3:{const locations=assets.filter(b=>b.type==='location');const upgraded=locations.filter(b=>s.assets[b.id].level>0);if(upgraded.length){upgraded.forEach(b=>{s.assets[b.id].level=0;});finish('All upgrades wiped.');}else{const b=best(locations);if(b)transfer(b,null);else pay(-200);finish(b?'Lost '+b.name+'.':'Paid up to £200 instead.');}break;}
  case 4: loseRolls();sendBreak(s,p,now);finish('Lost all rolls and went to Break.');break;
  case 5:{const rival=Object.values(s.players).filter(q=>eligible(q)&&q.id!==p.id).sort((a,b)=>worth(s,b)-worth(s,a)||a.id.localeCompare(b.id))[0];const list=rival?owned(rival):[];if(list.length){const b=list[rng(list.length)];transfer(b,p);finish('Stole '+b.name+' from '+rival.name+'.');}else{pay(250);finish('Collected £250 instead.');}break;}
  case 6: case 9: x.status='choice';x.remaining=i===9?2:1;x.picks=[];if(!choices().length)settleNoAssets();break;
  case 7: pay(1000);finish('Collected £1,000.');break;
  case 8: p.campaignRolls??=[];p.campaignRolls.push({count:10,expires:Math.min(now+7*86400000,finale),source:'liquidation'});finish('Gained 10 extra rolls.');break;
  case 10: p.campaignShield=5;finish('The bank will cover fees on the next five rolls.');break;
  case 11:{let n=0;for(const q of Object.values(s.players).filter(q=>eligible(q)&&q.id!==p.id))n+=money(s,q,-75,now,p,'liquidation');finish('Collected £'+n+' from the floor.');break;}
  case 12: x.status='choice';break;
 }
}
