// Entirely fictional game-bank contracts. No real lending or external payments.
export const familyTerms=[
 {id:'mob',name:'Send the Boys Round',text:'Destroy every upgrade owned by one player. Owe a favour: settle with £750 or your most valuable asset when called on one of your next three sign-ins, or within 72 hours at the latest. Unsettled favours become £1,000 debt, collected at 75% of future income.'},
 {id:'loan',name:'The Big Loan',text:'Receive £10,000. Owe £15,000. The Family takes 75% of future rent, skill fees, START SHIFT and arcade cash until paid.'},
 {id:'takeover',name:'An Offer They Can’t Refuse',text:'Take an owned asset, upgrades included. Owe three times its original price, collected at 75% of future income. The target gets 72 hours of Family protection.'},
 {id:'racket',name:'Protection Racket',text:'The bank covers fees on your next five board rolls. Afterwards, the Family takes all income from your next five positive rent or skill-fee collections.'},
 {id:'job',name:'One Last Job',text:'Get 15 extra rolls, valid seven days or until the finale. The Family takes your next five START SHIFT payments plus £500, collected at 75% of other covered income.'},
 {id:'burn',name:'Burn the Books',text:'Clear your Family contract by returning every location and role to the bank, removing upgrades and setting cash to £0. Keep your rolls. Once per game.'}
];
const hour=3600000;
const active=p=>p?.active&&!p.observer;
export function familyDebt(p){const c=p.family?.contract;return c?(c.debt||0)+(c.starts||0)*150+(c.favour?750:0):0;}
export function familyActive(p){const c=p.family?.contract;return !!c&&((c.debt||0)>0||(c.starts||0)>0||c.favour||(c.cover||0)>0||(c.collections||0)>0);}
export function familyEligible(s,p,now){return active(p)&&s.status==='running'&&p.cash<150&&Object.values(s.assets).filter(a=>a.owner===p.id).length<=2&&(!p.familyTransferAt||now-p.familyTransferAt>=72*hour);}
export function familyView(s,p,now){return {eligible:familyEligible(s,p,now),active:familyActive(p),debt:familyDebt(p),contract:p.family?.contract?Object.fromEntries(Object.entries(p.family.contract).filter(([k])=>!['favourSeen','favourAfter'].includes(k))):null,burnUsed:!!p.family?.burnUsed,cooldownUntil:p.familyTransferAt?p.familyTransferAt+72*hour:0,terms:familyTerms};}
export function familyVisit(s,p,session,now,event,notify){
 const c=p?.family?.contract;
 if(!c?.favour||c.favourCalled||!/^([0-9a-f]{64})$/.test(session||''))return;
 c.favourSeen??=[];if(c.favourSeen.includes(session))return;
 c.favourSeen.push(session);s.undo=null;
 if(c.favourSeen.length>=c.favourAfter+1){
  c.favourCalled=true;
  notify(p,'The Family called in your favour. Pay £750 or surrender your best asset before the 72-hour deadline.',now);
  event(s,p,'The Family called in '+p.name+'’s favour.',now,{kind:'family'});
 }
}
function complete(s,p,now,event,notify){
 if(p.family?.contract&&!familyActive(p)&&!p.family.contract.completed){
  p.family.contract.completed=now;event(s,p,p.name+' settled with The Family. PAID IN FULL.',now,{kind:'family'});
  notify(p,'PAID IN FULL. Pleasure doing business. Try not to need us again.',now);
 }
}
export function familyTick(s,now,event,notify){
 if(!s.started||s.status==='ended')return;
 for(const p of Object.values(s.players)){
  if(active(p)&&!p.familyNotified){notify(p,'The Family is opening behind the canteen. Under £150 and at most two assets? Read the contracts. Favours and debts are real game obligations; no real money.',now);p.familyNotified=true;s.undo=null;}
  const c=p.family?.contract;if(c?.favour&&now>=c.favourDue){
   c.favour=false;c.debt=(c.debt||0)+1000;c.rate=75;s.undo=null;
   event(s,p,p.name+' left a Family favour unpaid. £1,000 added to the ledger.',now,{kind:'family'});
   notify(p,'The favour expired. You now owe £1,000. We take 75% of covered future income.',now);
  }
 }
}
// Called after gross income is credited, without recursively calling money().
export function familySkim(s,p,amount,kind,now,event,notify){
 const c=p.family?.contract;
 if(!familyActive(p)||amount<=0||!['rent','skill','start','arcade'].includes(kind))return 0;
 let taken=0;
 if(kind==='start'&&c.starts>0){taken=Math.min(amount,c.starts*150);c.starts=Math.max(0,c.starts-Math.ceil(taken/150));}
 else if(['rent','skill'].includes(kind)&&c.collections>0&&c.cover===0){taken=amount;c.collections--;}
 else if(c.debt>0){taken=Math.min(c.debt,Math.ceil(amount*(c.rate||75)/100));c.debt-=taken;}
 if(taken){
  p.cash-=taken;p.stats.cashSpent+=taken;
  event(s,p,'The Family took £'+taken+' from '+p.name+'’s '+kind+' income. £'+(amount-taken)+' kept; £'+familyDebt(p)+' monetary liability remains.',now,{kind:'family_collection',amount:taken,player:p.id});
  notify(p,'The Family: you kept £'+(amount-taken)+', we took £'+taken+'. Monetary liability left: £'+familyDebt(p)+'.',now);
 }
 complete(s,p,now,event,notify);return taken;
}
export function familyCover(p){const c=p.family?.contract;return !!c&&c.cover>0;}
export function familyRoll(s,p,now,event,notify){
 const c=p.family?.contract;if(c?.cover>0)c.cover--;complete(s,p,now,event,notify);
}
export function familyAction(s,p,args,now,rng,h){
 const {board,money,event,notify}=h;
 if(!active(p)||s.status!=='running')throw Error('The Family is closed');
 const own=id=>board.filter(b=>s.assets[b.id]?.owner===id);
 const best=list=>[...list].sort((a,b)=>b.price+s.assets[b.id].level*(b.upgrade||0)-a.price-s.assets[a.id].level*(a.upgrade||0)||a.id-b.id)[0];
 const transfer=(b,to)=>{
  const a=s.assets[b.id];a.owner=to?.id||null;if(!to)a.level=0;a.open=false;
  if(to)to.wanted=(to.wanted||[]).filter(id=>id!==b.id);
  for(const t of s.trades)if(t.status==='pending'&&(t.give.includes(b.id)||t.want.includes(b.id))){
   t.status='cancelled';for(const id of [t.from,t.to])if(s.players[id])notify(s.players[id],'Trade cancelled: The Family changed ownership of '+b.name+'.',now);
  }
 };
 p.family??={};const f=p.family,c=f.contract;
 if(args.deal==='settle'){
  if(!c?.favour)throw Error('No outstanding favour');
  if(args.method==='cash'){if(p.cash<750)throw Error('You need £750');money(s,p,-750,now,null,'family');}
  else if(args.method==='asset'){const b=best(own(p.id));if(!b)throw Error('You own no assets');transfer(b,null);}
  else throw Error('Choose £750 or your most valuable asset');
  c.favour=false;event(s,p,p.name+' settled the favour with '+(args.method==='cash'?'£750':'their most valuable asset')+'.',now,{kind:'family'});complete(s,p,now,event,notify);return;
 }
 if(args.deal==='burn'){
  if(!familyActive(p)||f.burnUsed)throw Error('Burn the Books is unavailable');
  if(p.familyTransferAt&&now-p.familyTransferAt<72*hour)throw Error('Wait 72 hours after a voluntary transfer');
  own(p.id).forEach(b=>transfer(b,null));money(s,p,-p.cash,now,null,'family');f.burnUsed=true;f.contract=null;
  event(s,p,p.name+' burned the books. All assets surrendered; cash £0; Family obligations cleared.',now,{kind:'family'});return;
 }
 if(!familyEligible(s,p,now))throw Error('You need under £150, at most two assets, and no voluntary transfers in the last 72 hours');
 if(familyActive(p))throw Error('One Family contract at a time');
 if(!familyTerms.some(t=>t.id===args.deal))throw Error('Choose a Family contract');
 let contract={kind:args.deal,debt:0,starts:0,cover:0,collections:0,rate:75,at:now};
 if(args.deal==='loan'){contract.debt=15000;money(s,p,10000,now,null,'family');}
 else if(args.deal==='job'){
  contract.debt=500;contract.starts=5;p.campaignRolls??=[];p.campaignRolls.push({count:15,expires:Math.min(now+7*86400000,s.endsAt||Infinity),source:'family'});
 }else if(args.deal==='racket'){contract.cover=5;contract.collections=5;}
 else if(args.deal==='mob'||args.deal==='takeover'){
  const b=Number.isInteger(args.asset)?board[args.asset]:null;
  const target=args.deal==='mob'?s.players[args.target]:s.players[s.assets[b?.id]?.owner];
  if(!active(target)||target.id===p.id)throw Error('Choose another active player');
  if((target.familyProtectedUntil||0)>now)throw Error('This player has 72-hour Family protection');
  if(args.deal==='mob'){
   const upgraded=own(target.id).filter(b=>s.assets[b.id].level>0);if(!upgraded.length)throw Error('The target has no upgrades');
   upgraded.forEach(b=>{s.assets[b.id].level=0;});
   contract.favour=true;contract.favourDue=now+72*hour;contract.favourAfter=rng(3)+1;contract.favourSeen=[args.serverSession||'accepted'];
   event(s,p,'THE FAMILY PAID '+target.name+' A VISIT. All upgrades destroyed. Commissioned by '+p.name+'.',now,{kind:'family_attack',target:target.id});
   notify(target,p.name+' sent The Family. Every upgrade you owned was destroyed. Your locations remain. You have 72 hours of Family protection.',now);
  }else{
   if(!b?.price)throw Error('Choose an owned asset');
   contract.debt=b.price*3;contract.collateral=b.id;transfer(b,p);
   notify(target,p.name+' commissioned a Family takeover of '+b.name+'. You have 72 hours of Family protection.',now);
   event(s,p,p.name+' took '+b.name+' from '+target.name+' through The Family.',now,{kind:'family_attack',target:target.id});
  }
  target.familyProtectedUntil=now+72*hour;
 }else throw Error('Unavailable deal');
 f.contract=contract;
 // Offers created before borrowing must not export new loan proceeds or collateral.
 for(const t of s.trades)if(t.status==='pending'&&[t.from,t.to].includes(p.id)){t.status='cancelled';for(const id of [t.from,t.to])if(s.players[id])notify(s.players[id],'Trade cancelled because '+p.name+' signed a Family contract.',now);}
 event(s,p,p.name+' signed '+familyTerms.find(t=>t.id===args.deal).name+' with The Family.',now,{kind:'family'});
}
