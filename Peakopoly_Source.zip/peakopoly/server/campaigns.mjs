import {deal,dealAt,themeEnd} from './liquidation.mjs';
const at = day => Date.parse(day+'Z');
export const calendar = Object.freeze({
  rentStart: at('2026-11-08T04:30:00'), rentEnd: at('2026-11-15T04:30:00'), prizeEnd: at('2026-11-22T04:30:00'),
  saleStart: dealAt, saleEnd: themeEnd,
  cyberStart: at('2026-11-30T00:00:00'), cyberEnd: at('2026-12-01T00:00:00'), cyberRollEnd: at('2026-12-06T04:30:00'),
  adventStart: at('2026-12-01T00:00:00'), finale: at('2026-12-24T19:00:00')
});
const dayMs=86400000;
const prizes=[50,25,0], teamNames=['The Dock Deals','The Rent Rangers','The Forklift Tycoons'];
const inWindow=(now,start,end)=>now>=start&&now<end;
const enabled=s=>s.campaigns?.enabled===true;
const live=(s,p)=>enabled(s)&&s.status==='running'&&p?.active&&!p.observer;

function shuffled(list,rng){const out=[...list];for(let i=out.length-1;i>0;i--){const j=rng(i+1);[out[i],out[j]]=[out[j],out[i]];}return out;}
export function standings(teams){
  return teams.map(t=>({...t,total:t.members.reduce((n,m)=>n+m.rent,0)})).filter(t=>t.members.length)
    .sort((a,b)=>b.total*a.members.length-a.total*b.members.length||a.tie-b.tie);
}
export function tickCampaigns(s,now,rng,notify,event){
  if(!enabled(s))return;
  deal(s,now,rng,notify,event);
  const c=s.campaigns;
  if(!c.rent&&inWindow(now,calendar.rentStart,calendar.rentEnd)){
    const members=shuffled(Object.values(s.players).filter(p=>p.active&&!p.observer),rng);
    const teams=shuffled(teamNames,rng).map((name,tie)=>({name,tie,members:[]}));
    members.forEach((p,i)=>teams[i%3].members.push({id:p.id,name:p.name,rent:0}));
    c.rent={teams};
    s.undo=null;
    event(s,null,'Rent Wars has begun. Check the campaign desk for your team.',now);
  }
  if(c.rent&&!c.rent.final&&now>=calendar.rentEnd){
    c.rent.final=standings(c.rent.teams).map((t,i)=>({...t,prize:prizes[i]}));
    for(const team of c.rent.final){
      const each=Math.floor(team.prize/team.members.length), remainder=team.prize%team.members.length;
      team.members.forEach((m,i)=>{
        const n=each+(i<remainder?1:0),p=s.players[m.id];
        if(!n||!p)return;
        grant(p,n,calendar.prizeEnd,'rent');
        notify(p,team.name+' earned you '+n+' Rent Wars rolls. Spend them before Sunday 22 November at 04:30.',now);
      });
    }
    s.undo=null;
    event(s,null,'Rent Wars has finished. Prize rolls are in the campaign allowance.',now);
  }
}
export function recordRent(s,p,amount,now){
  if(!enabled(s)||!inWindow(now,calendar.rentStart,calendar.rentEnd))return;
  for(const t of s.campaigns.rent?.teams||[]){const m=t.members.find(x=>x.id===p.id);if(m){m.rent+=amount;return;}}
}
function grant(p,count,expires,source){p.campaignRolls??=[];p.campaignRolls.push({count,expires,source});}
export function bonusRolls(s,p,now){return s.status==='ended'?0:(p?.campaignRolls||[]).reduce((n,r)=>n+(r.expires>now?r.count:0),0);}
export function spendRoll(s,p,now){
  if(p.rolls>0){p.rolls--;return true;}
  const next=(p.campaignRolls||[]).filter(r=>r.count>0&&r.expires>now).sort((a,b)=>a.expires-b.expires)[0];
  if(!next)return false;
  next.count--;return true;
}
export function voucherAvailable(s,p,now){return false;}
export function purchasePrice(s,p,price,useVoucher,now){
  if(!useVoucher)return price;
  if(!voucherAvailable(s,p,now))throw Error('Your Black Friday voucher is unavailable');
  return price-Math.min(60,Math.floor(price/5));
}
export function recordActivity(s,p,kind,now,notify,event){
  if(!live(s,p))return;
  if(kind==='arcade'&&inWindow(now,calendar.cyberStart,calendar.cyberEnd)&&!p.campaignCyber){
    p.campaignCyber=true;
    grant(p,1,calendar.cyberRollEnd,'cyber');
    notify(p,'Scanner Glitch cleared! You earned one Cyber Monday roll.',now);
    event(s,p,p.name+' earned a Cyber Monday roll.',now);
  }
  if(inWindow(now,calendar.adventStart,calendar.finale)){
    p.campaignActivity??={};
    p.campaignActivity[kind]=now;
  }
}
const doors=[
 ['cash',15],['arcade',20],['roll',1],['turn',20],['cash',20],['arcade',15],
 ['cash',15],['turn',20],['roll',1],['arcade',20],['cash',15],['turn',15],
 ['cash',20],['arcade',20],['roll',1],['turn',20],['cash',15],['arcade',20],
 ['cash',20],['turn',15],['roll',1],['arcade',20],['cash',20],['turn',25]
];
function doorInfo(d,now,p){
  const [kind,amount]=doors[d-1], opens=calendar.adventStart+(d-1)*dayMs, expires=Math.min(opens+2*dayMs,calendar.finale);
  const claimed=!!p?.campaignDoors?.[d], open=inWindow(now,opens,expires);
  const ready=kind==='cash'||kind==='roll'||(p?.campaignActivity?.[kind]??0)>=opens;
  const label=kind==='roll'?'One bonus roll':kind==='cash'?'£'+amount+' in game cash':(kind==='turn'?'Take a board turn':'Finish an arcade game')+' for £'+amount;
  return {day:d,kind,amount,opens,expires,claimed,open,ready,label};
}
export function adventToday(now){
  if(!inWindow(now,calendar.adventStart,calendar.finale))return null;
  return doorInfo(Math.floor((now-calendar.adventStart)/dayMs)+1,now);
}
export function claimDoor(s,p,d,now,money,event){
  if(!live(s,p)||!Number.isInteger(d)||d<1||d>24)throw Error('Advent door unavailable');
  const x=doorInfo(d,now,p);
  if(!x.open||x.claimed||!x.ready)throw Error('This door is locked, expired, claimed, or its challenge is unfinished');
  p.campaignDoors??={};
  p.campaignDoors[d]=true;
  if(x.kind==='roll')grant(p,1,calendar.finale,'advent');
  else money(s,p,x.amount,now,null,'advent');
  event(s,p,p.name+' opened Advent door '+d+' and collected '+(x.kind==='roll'?'one roll':'£'+x.amount)+'.',now);
}
export function campaignView(s,p,now){
  if(!enabled(s))return null;
  const r=s.campaigns.rent;
  return {calendar,phase:inWindow(now,calendar.rentStart,calendar.rentEnd)?'rent':inWindow(now,calendar.rentEnd,calendar.prizeEnd)?'prizes':inWindow(now,calendar.saleStart,calendar.saleEnd)?'sale':inWindow(now,calendar.cyberStart,calendar.cyberEnd)?'cyber':inWindow(now,calendar.adventStart,calendar.finale)?'advent':null,
    rent:r?{teams:r.final||standings(r.teams),final:!!r.final}:null,
    rolls:bonusRolls(s,p,now),voucher:voucherAvailable(s,p,now),cyber:!!p?.campaignCyber,
    doors:doors.map((_,i)=>doorInfo(i+1,now,p)).filter(d=>d.open)};
}
