import {calendar,adventToday,standings,bonusRolls} from './campaigns.mjs';
import {london,dayKey,worth} from './engine.mjs';
export const slackDefaults={enabled:false,mentionChannel:true,hype:false,hypeTime:'19:00',launch:true,daily:true,dailyTime:'09:00',reset:true,resetTime:'18:00',weekly:true,finish:true};
const link='<https://brdlnx-ld.github.io/peakopoly/index.html|Open Peakopoly →>';
const lines=['Your empire won’t build itself. Your daily roll and the Breakroom Arcade are waiting.','Main Office won’t buy itself. Take your roll, try the arcade and make your next move.','The scanner is charged. Is your property empire? Your roll and arcade challenges are ready.','Someone else could own the floor by the time you finish your coffee. Make your next move.','L&D has no budget. Luckily, Peakopoly does. Your daily roll and arcade challenges are waiting.'];
export const safe=s=>String(s??'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])).replace(/[*_~`]/g,'');
export function dailyText(now,mention=false){return (mention?'<!channel>\n':'')+'🎩 *Peakopoly — your shift nudge*\n'+lines[Math.floor(Date.parse(dayKey(now))/86400000)%lines.length]+'\nUnused rolls expire Sunday at 04:30 London time.\n'+link;}
const hypeLines=[
 'Main Office is still available. So is your chance to own it. Sign up before someone else gets ideas.',
 'I have polished the scanner and counted the parcels. Now I need a Training Team with questionable property ambitions.',
 'L&D has no budget. Peakopoly gives you £1,200. I know which meeting I would rather attend.',
 'Your future landlord might be sitting next to you. Sign up and give them some competition.',
 'The floor is empty, the licences are waiting, and I look excellent in this vest. Join us.',
 'Trade locations, collect skill fees and become suspiciously interested in the price of the Locker Room.',
 'A roll a day. A portfolio to build. A leaderboard to climb. Your next training challenge has a scanner and a bowler hat.',
 'The Breakroom Arcade is warming up: spin the wheel, predict volume and pack the container once we launch.',
 'One teammate completed a lap in a week during testing. Imagine what the whole Training Team can get up to.',
 'You can keep your existing account. New players: choose your name, token and PIN, then wait for Admin approval.',
 'No entry fee, no real money, plenty of bragging rights. Come and claim your place on the floor.',
 'Peak is approaching. My investment advice: sign up, learn the rules and keep an eye on Main Office.'
];
const signup='<https://brdlnx-ld.github.io/peakopoly/index.html#signup|Sign up for Peakopoly →>';
export function hypeText(s,now,mention=false){const days=Math.max(0,Math.ceil((s.startsAt-now)/86400000)),offset=Math.max(0,Math.round((Date.parse(dayKey(now))-Date.parse(dayKey(s.launchPreparedAt||now)))/86400000)),order=s.hypeOrder?.length===hypeLines.length?s.hypeOrder:hypeLines.map((_,i)=>i),line=hypeLines[order[offset%order.length]],date=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London',weekday:'long',day:'numeric',month:'long',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(s.startsAt);return (mention?'<!channel>\n':'')+'🎩 *Peakopoly — the floor opens soon*\n'+line+'\nLaunch: '+date+' London time'+(days?' · '+days+' days to go':'')+'.\nEveryone starts fresh with £1,200. Existing players keep their account and PIN. New registrations need Admin approval.\n'+signup;}
export function launchText(mention=false){return (mention?'<!channel>\n':'')+'🚀 *Peakopoly is LIVE!*\nThe floor is open. Everyone starts with £1,200 and one roll. Locations, role licences, trading and the Breakroom Arcade are ready.\nUse your existing account, or request to join if you are new.\n'+link;}
export function resetText(){return '🎩 *Last call for this week’s rolls!*\nUnused normal and bonus rolls expire Sunday at 04:30 London time. Your cash, portfolio and cards stay with you.\n'+link;}
export function weeklyText(summary){
 const a=summary.awards||{},cash=n=>'£'+Number(n||0).toLocaleString('en-GB');
 const awards=[['🤝 Deal Maker','trades',n=>n+' completed '+(n===1?'trade':'trades')],['💰 Rent Collector','rent',cash],['☕ Most Trips to Break','breaks',n=>n+' '+(n===1?'trip':'trips')]];
 const prizes=awards.map(([title,k,format])=>{
  const value=a[k]?.[k]||0;if(value<=0)return '*'+title+'*: no winner this week.';
  const tied=(summary.rows||[]).filter(r=>r[k]===value);
  const names=tied.length?tied.slice(0,4).map(r=>safe(r.name)).join(', ')+(tied.length>4?' + '+(tied.length-4)+' more':''):safe(a[k].name);
  return '*'+title+'*: '+names+' · '+format(value);
 });
 return '🏆 *Peakopoly — weekly floor report*\nBiggest net-worth increase: '+(a.increase?safe(a.increase.name)+' ('+cash(a.increase.increase)+')':'No result')+'\nMost doubles: '+(a.doubles?.doubles>0?safe(a.doubles.name)+' ('+a.doubles.doubles+')':'No result')+'\n\n🎩 *Mascot’s weekly awards*\n'+prizes.join('\n')+'\n\nThe new week is live. Old rolls expired; one new roll has been granted.\n'+link;
}
export function finishText(s){const rows=(s.results||s.trialResults||[]).slice().sort((a,b)=>b.netWorth-a.netWorth);return '🏁 *Peakopoly — round complete*\n'+rows.slice(0,3).map((p,i)=>`${i+1}. ${safe(p.name)} — £${Number(p.netWorth).toLocaleString('en-GB')} net worth`).join('\n')+'\nFinal results are saved in the game. Thanks for playing!\n'+link;}
const campaignLink='<https://brdlnx-ld.github.io/peakopoly/#campaigns|Open the Campaign Desk →>';
const gbp=n=>'£'+n.toLocaleString('en-GB');
const isBetween=(now,from,to)=>now>=from&&now<to;
export function dailyDigest(s,now){
 const localDate=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London',dateStyle:'short'}),day=localDate.format(now);
 const today=x=>Number.isFinite(x.at)&&x.at<=now&&localDate.format(x.at)===day;
 const players=Object.values(s.players||{}).filter(p=>p.active&&!p.observer);
 const rolls=(s.rollHistory||[]).filter(today),rent=(s.feed||[]).filter(x=>x.kind==='rent'&&x.amount>0&&today(x));
 const rolled=new Set(rolls.map(x=>x.player)).size,doubles=rolls.filter(x=>x.dice?.length===2&&x.dice[0]===x.dice[1]).length;
 const biggest=rent.reduce((max,x)=>!max||x.amount>max.amount?x:max,null);
 const top=players.map(p=>({name:p.name,value:worth(s,p)})).sort((a,b)=>b.value-a.value||a.name.localeCompare(b.name)).slice(0,3);
 const parts=['🎩 *Peakopoly — daily floor report*'];
 const event=s.campaigns?.enabled;
 if(event&&isBetween(now,calendar.rentStart,calendar.rentEnd)){
  const teams=standings(s.campaigns.rent?.teams||[]);
  parts.push('⚑ *Rent Wars standings*',...teams.map((t,i)=>(i+1)+'. *'+safe(t.name)+'* — '+gbp(t.total)+' total · £'+(t.total/t.members.length).toFixed(2)+' per player'));
  if(teams.length>1&&teams[0].total*teams[1].members.length===teams[1].total*teams[0].members.length)parts.push('It’s a tie at the top on rent per player.');
  parts.push('Property rent counts towards your team. Scoring closes Sunday 15 November at 04:30.');
 }else if(event&&isBetween(now,calendar.rentEnd,calendar.prizeEnd)){
  const left=players.reduce((n,p)=>n+bonusRolls(s,p,now),0);
  parts.push('🏆 *Rent Wars prize week* — '+left+' campaign rolls still available across active players. Spend yours before Sunday 22 November at 04:30.');
 }else if(event&&isBetween(now,calendar.saleStart,calendar.saleEnd)){
  const used=players.filter(p=>p.campaignVoucherUsed).length;
  parts.push('🏷️ *Black Friday Clearance Sale* — '+used+' of '+players.length+' active players have used their voucher. Use yours for 20% off a property, licence or upgrade (up to £60 off) before Sunday 29 November at 04:30.');
 }else if(event&&isBetween(now,calendar.cyberStart,calendar.cyberEnd)){
  const cleared=players.filter(p=>p.campaignCyber).length;
  parts.push('⚡ *Cyber Monday: Scanner Glitch* — '+cleared+' players have earned the bonus so far. Finish any arcade game before midnight to earn one campaign roll.');
 }else if(event&&adventToday(now)){
  const door=adventToday(now),opened=players.filter(p=>p.campaignDoors?.[door.day]).length;
  parts.push('🎄 *Peakopoly Advent — door '+door.day+'* — '+door.label+'. '+opened+' of '+players.length+' active players have claimed it. Doors stay open up to 48 hours and close at the Christmas Eve finale.');
 }
 parts.push('', '*Today on the board*',
  rolls.length?rolls.length+' board '+(rolls.length===1?'roll':'rolls')+' by '+rolled+' '+(rolled===1?'player':'players')+' · '+doubles+' doubles.':'No board rolls recorded today yet.',
  rent.length?gbp(rent.reduce((n,x)=>n+x.amount,0))+' in property rent paid'+(s.players?.[biggest.recipient]?' · largest payment: '+gbp(biggest.amount)+' to '+safe(s.players[biggest.recipient].name):'')+'.':'No property rent recorded today yet.');
 if(top.length)parts.push('', '*Net worth leaders*',...top.map((p,i)=>(i+1)+'. '+safe(p.name)+' — '+gbp(p.value)));
 if(event&&dayKey(now)==='2026-11-11'&&isBetween(now,calendar.rentStart,calendar.rentEnd)){
  parts.push('', '🤝 *Wednesday Trade Desk*', 'Reply in this thread with one property you want and one you’d consider trading. If you find a match, make the offer in Peakopoly.');
 }
 parts.push('', 'Normal rolls expire Sunday at 04:30 London time.',event?campaignLink:link);
 return parts.join('\n');
}
export function scheduledMessages(s,now){const c={...slackDefaults,...s.slackConfig},p=london(now),minute=+p.hour*60+(+p.minute),near=t=>{const [h,m]=t.split(':').map(Number);return minute>=h*60+m&&minute<h*60+m+5;},out=[];if(!c.enabled||(c.stopAt&&now>=c.stopAt))return out;
if(s.status==='scheduled'&&c.hype&&now<s.startsAt&&near(c.hypeTime))out.push({id:'hype:'+dayKey(now),text:hypeText(s,now,c.mentionChannel)});
if(s.status==='running'){if(c.launch&&s.launchedAt&&now>=s.launchedAt&&now-s.launchedAt<86400000)out.push({id:'launch:'+s.launchedAt,text:launchText(c.mentionChannel)});const campaign=s.campaigns?.enabled, cyber=campaign&&now>=calendar.cyberStart&&now<calendar.cyberEnd;
if(c.daily&&near(cyber?'09:00':c.dailyTime)){
 out.push({id:'daily:'+dayKey(now),text:(c.mentionChannel?'<!channel>\n':'')+dailyDigest(s,now)});
}if(c.reset&&p.weekday==='Sat'&&near(c.resetTime))out.push({id:'reset:'+s.week,text:(c.mentionChannel?'<!channel>\n':'')+resetText()});}
const summary=s.summaries[0];if(c.weekly&&s.status==='running'&&summary&&summary.at>c.enabledAt&&now-summary.at<86400000)out.push({id:'weekly:'+summary.week,text:weeklyText(summary)+campaignRoundup(s,now)});
if(c.finish&&s.status==='ended'&&s.endedAt>c.enabledAt&&now-s.endedAt<86400000)out.push({id:'finish:'+s.endedAt,text:finishText(s)});return s.roundId?out.map(m=>({...m,id:s.roundId+':'+m.id})):out;}
function campaignRoundup(s,now){
 if(!s.campaigns?.enabled)return '';
 if(now>=calendar.rentStart&&now<calendar.rentStart+86400000&&s.campaigns.rent?.teams){
  const roster=s.campaigns.rent.teams.filter(t=>t.members.length).map(t=>'*'+safe(t.name)+' ('+t.members.length+')* — '+t.members.map(m=>safe(m.name)).join(', ')).join('\n');
  return '\n\n🎩 *Rent Wars is live — meet your teams!*\n'+roster+'\n\nProperty rent collected counts. The highest rent per player wins. First shares 50 rolls; second shares 25. Ends Sunday 15 November at 04:30.\n<https://brdlnx-ld.github.io/peakopoly/#campaigns|Check the Campaign Desk →>';
 }
 if(now>=calendar.rentEnd&&now<calendar.rentEnd+86400000&&s.campaigns.rent?.final)return '\n🏆 *Rent Wars results*\n'+s.campaigns.rent.final.map((t,i)=>(i+1)+'. '+safe(t.name)+' — £'+t.total+' total, £'+(t.total/t.members.length).toFixed(2)+' per player · '+t.prize+' prize rolls').join('\n')+'\nSpend your prize rolls by 04:30 next Sunday.';
 if(now>=calendar.saleStart&&now<calendar.saleStart+86400000)return '\n🛒 *Black Friday Clearance Sale* is open. Use one 20% voucher (up to £60 off) on a property, role licence or upgrade before 04:30 next Sunday.';
 return '';
}
export const mascotImage='https://brdlnx-ld.github.io/peakopoly/peakopoly-logo.png';
export function channelText(text){return '<!channel>\n'+String(text).replaceAll('<!channel>','').trim();}
export function slackPayload(text){const tagged=channelText(text);return {text:tagged,blocks:[{type:'section',text:{type:'mrkdwn',text:tagged}},{type:'image',image_url:mascotImage,alt_text:'Peakopoly mascot and logo in navy, white and lime'}],unfurl_links:false,unfurl_media:false};}
export async function deliverSlack(db,rpc){const hook=await rpc('peak_slack_webhook',{});if(typeof hook!=='string'||!/^https:\/\/hooks\.slack\.com\/services\/[A-Za-z0-9]+\/[A-Za-z0-9]+\/[A-Za-z0-9]+$/.test(hook))return {status:'not_connected'};const jobs=await rpc('peak_slack_claim',{});if(!jobs.length)return {status:'idle'};const j=jobs[0],path='peak_slack_outbox?id=eq.'+encodeURIComponent(j.id);let change;
try{const response=await fetch(hook,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(slackPayload(j.text)),signal:AbortSignal.timeout(10000)});if(response.ok){change={status:'sent',detail:'Slack accepted the message'};}else if(response.status===429){const seconds=Math.max(60,Math.min(3600,Number(response.headers.get('retry-after'))||60));change={status:'pending',detail:'Rate limited; retry scheduled',retry_at:new Date(Date.now()+seconds*1000).toISOString()};}else{change={status:response.status>=500?'unknown':'failed',detail:'Slack HTTP '+response.status};}}
catch{change={status:'unknown',detail:'Delivery could not be confirmed. Check Slack before sending again.'};}
await db(path,'PATCH',{...change,updated:new Date().toISOString()});return {status:change.status};}
export async function runSlack(s,now,db,rpc){for(const msg of scheduledMessages(s,now))await rpc('peak_slack_enqueue',{p_id:msg.id,p_text:msg.text,p_actor:'scheduler'});return deliverSlack(db,rpc);}
export const testText='🧪 *Peakopoly connection test*\nThe webhook is connected. This is a connection test, not a game result. Manage reminders in the Peakopoly Admin desk.\n'+link;
