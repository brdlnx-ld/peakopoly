import {adventCards,cardById,adventStart,closingStart,adventEnd} from './adventdeck.mjs';
const active=p=>p?.active&&!p.observer;
const dayAt=now=>Math.min(24,Math.floor((now-adventStart)/86400000)+1);
const shuffled=(list,rng)=>{const a=[...list];for(let i=a.length-1;i>0;i--){const j=rng(i+1);[a[i],a[j]]=[a[j],a[i]];}return a;};
export function adventDeal(s,now,rng,event,notify){
 if(!s.campaigns?.enabled||s.status!=='running'||now<adventStart||now>=adventEnd||s.campaigns.advent)return;
 const players=Object.values(s.players).filter(active);
 if(players.length!==13){
  if(s.campaigns.adventBlocked!==players.length){s.campaigns.adventBlocked=players.length;s.undo=null;event(s,null,'Advent draw waiting: exactly 13 active players are required.',now);for(const p of Object.values(s.players).filter(p=>p.observer&&p.active))notify(p,'Advent draw blocked: '+players.length+' active players, expected 13.',now);}
  return;
 }
 const main=shuffled(adventCards.filter(c=>!c.closing),rng),close=shuffled(adventCards.filter(c=>c.closing),rng);
 s.campaigns.advent={dealt:now,hands:Object.fromEntries(players.map((p,i)=>[p.id,Array.from({length:24},(_,d)=>({day:d+1,id:d<22?main[d*13+i].id:close[(d-22)*13+i].id,status:'sealed'}))]))};
 s.undo=null;event(s,null,'Advent Anarchy: 312 unique cards have been dealt. One daily card per player; future cards stay secret.',now);
 for(const p of players)notify(p,'Advent Anarchy is live. Your daily mystery card is waiting in the Campaign Desk.',now);
}
export function adventPending(s,p,now){
 if(!active(p)||now<adventStart||now>=adventEnd)return null;
 return s.campaigns?.advent?.hands[p.id]?.find(x=>x.day<=dayAt(now)&&x.status!=='done')||null;
}
export function adventView(s,p,now){
 const hand=s.campaigns?.advent?.hands[p?.id]||[];
 return {blocked:s.campaigns?.adventBlocked!==undefined&&!s.campaigns.advent,
  catalogue:312,allocated:hand.length,
  doors:hand.map(x=>({day:x.day,status:x.status,ready:now>=adventStart+(x.day-1)*86400000&&now<adventEnd,opens:adventStart+(x.day-1)*86400000,
   ...(x.status==='sealed'?{}:{card:cardById[x.id],result:x.result,at:x.at})})),
  results:Object.entries(s.campaigns?.advent?.hands||{}).flatMap(([id,rows])=>rows.filter(x=>x.status==='done').map(x=>({name:s.players[id]?.name,day:x.day,title:cardById[x.id].title,result:x.result,at:x.at}))).sort((a,b)=>b.at-a.at).slice(0,40)};
}
export function resolveAdvent(s,p,action,args,now,rng,h,previewCard=null){
 const x=previewCard?{day:1,id:previewCard,status:'sealed'}:adventPending(s,p,now);
 if(!x)throw Error('No Advent card ready');
 if(!previewCard&&args.day!==x.day)throw Error('Open the oldest available Advent day first; refresh the card');
 const card=cardById[x.id];if(!card)throw Error('Unknown Advent card');
 const e=card.effect,{board,money,event,notify,worth,sendBreak}=h;
 const own=q=>board.filter(b=>s.assets[b.id]?.owner===q.id);
 const fits=b=>e.kind==='any'||b.type===e.kind;
 const amount=b=>b.price+(s.assets[b.id]?.level||0)*(b.upgrade||0);
 const choose=list=>!list.length?null:e.pick==='highest'?[...list].sort((a,b)=>amount(b)-amount(a)||a.id-b.id)[0]:e.pick==='lowest'?[...list].sort((a,b)=>amount(a)-amount(b)||a.id-b.id)[0]:list[rng(list.length)];
 const pay=n=>money(s,p,n,now,null,'advent');
 const rolls=n=>{if(n>0){p.campaignRolls??=[];p.campaignRolls.push({count:n,expires:Math.min(now+7*86400000,adventEnd),source:'advent'});}};
 const move=(b,to)=>{
  const asset=s.assets[b.id],prior=s.players[asset.owner];asset.owner=to?.id||null;if(!to)asset.level=0;asset.open=false;
  if(to)to.wanted=(to.wanted||[]).filter(id=>id!==b.id);
  for(const t of s.trades)if(t.status==='pending'&&(t.give.includes(b.id)||t.want.includes(b.id))){
   t.status='cancelled';for(const id of [t.from,t.to])if(s.players[id])notify(s.players[id],'Trade cancelled: Advent changed ownership of '+b.name+'.',now);
  }
  if(prior&&prior.id!==p.id)notify(prior,'Advent moved '+b.name+(to?' to '+to.name:' back to the bank')+'.',now);
  if(to&&to.id!==p.id)notify(to,'Advent transferred '+b.name+' to you.',now);
 };
 const finish=result=>{x.status='done';x.result=result;x.at=now;event(s,p,p.name+' opened Advent day '+x.day+': '+card.title+' — '+result,now,{kind:'advent',card:card.id});};
 if(!previewCard&&now>=closingStart&&!card.closing&&!(['grant','protection','claim'].includes(e.type)||e.type==='rolls'&&e.cash>=0)){
  if(e.type==='gamble'&&e.loss===0){}else{pay(50);finish('Late-opening protection: £50 instead of a disruptive effect.');return;}
 }
 if(e.type==='gamble'){
  if(action==='advent_open'){x.status='choice';return;}
  if(!previewCard&&x.status!=='choice')throw Error('Reveal the card before choosing');
  if(action!=='advent_choose'||!['safe','risk'].includes(args.choice))throw Error('Choose safe cash or gamble');
  if(args.choice==='safe'){pay(e.safe);finish('Took £'+e.safe+' safely.');}
  else if(rng(2)===0){pay(e.win);finish('Gambled and won £'+e.win+'.');}
  else{const paid=money(s,p,-e.loss,now,null,'advent');finish(e.loss?'Gambled and paid £'+paid+'.':'Gambled and won nothing.');}
  return;
 }
 if(action!=='advent_open')throw Error('This card has no choice');
 if(e.type==='grant'||e.type==='rolls'){pay(e.cash);rolls(e.rolls);finish((e.cash>=0?'Collected ':'Paid up to ')+'£'+Math.abs(e.cash)+'; gained '+e.rolls+' bonus roll(s).');}
 else if(e.type==='tax'){const paid=money(s,p,-Math.min(e.cap,Math.floor(p.cash*e.percent/100)),now,null,'advent');rolls(e.rolls);finish('Paid £'+paid+'; received '+e.rolls+' rolls.');}
 else if(e.type==='collect'){
  const rivals=Object.values(s.players).filter(q=>active(q)&&q.id!==p.id&&(e.comparison==='assets'?own(q).length>own(p).length:worth(s,q)>worth(s,p)));
  let total=0;for(const q of rivals)total+=money(s,q,-e.amount,now,p,'advent');
  if(!rivals.length){pay(e.fallback);total=e.fallback;}finish('Collected £'+total+(rivals.length?' from '+rivals.length+' eligible player(s).':' from the bank instead.'));
 }
 else if(e.type==='claim'){
  const targets=board.filter(b=>b.price&&fits(b)&&!s.assets[b.id].owner&&b.price<=e.limit),b=targets.length?targets[rng(targets.length)]:null;
  if(b){move(b,p);finish('Claimed '+b.name+' free.');}else{pay(e.fallback);finish('No eligible unowned asset: collected £'+e.fallback+'.');}
 }
 else if(e.type==='sale'){
  const b=choose(own(p).filter(fits));if(b){const cash=Math.floor(b.price*e.percent/100);move(b,null);pay(cash);finish('Sold '+b.name+' for £'+cash+'.');}
  else{const paid=money(s,p,-e.fallback,now,null,'advent');finish('No eligible asset: paid £'+paid+'.');}
 }
 else if(e.type==='steal'||e.type==='swap'){
  const rivals=Object.values(s.players).filter(q=>active(q)&&q.id!==p.id&&(e.comparison==='assets'?own(q).length>own(p).length:worth(s,q)>worth(s,p)));
  const targets=rivals.flatMap(q=>own(q).filter(fits)),b=choose(targets),mine=e.type==='swap'?choose(own(p).filter(fits)):null;
  if(b&&(e.type==='steal'||mine)){
   const owner=s.players[s.assets[b.id].owner];move(b,p);if(mine)move(mine,owner);
   finish(mine?'Swapped '+mine.name+' for '+b.name+' with '+owner.name+'.':'Took '+b.name+' from '+owner.name+'.');
  }else{pay(e.fallback);finish('No eligible '+(e.type==='swap'?'swap':'target')+': collected £'+e.fallback+'.');}
 }
 else if(e.type==='protection'){p.campaignShield=(p.campaignShield||0)+e.count;pay(e.cash);finish('Collected £'+e.cash+'; added '+e.count+' protected board rolls.');}
 else if(e.type==='disaster'){
  if(e.mode==='liquidate'){
   pay(-p.cash);p.rolls=0;p.campaignRolls=[];p.campaignShield=0;own(p).forEach(b=>move(b,null));
   for(let i=0;i<p.cards;i++)s.discards.training.push(3);p.cards=0;if(p.mini)p.mini.session=null;sendBreak(s,p,now);finish('Full liquidation. All holdings wiped; sent to Break.');
  }else if(e.mode==='cash'){const paid=money(s,p,-Math.floor(p.cash*e.percent/100),now,null,'advent');rolls(e.rolls);finish('Lost £'+paid+'; received '+e.rolls+' rolls.');}
  else if(e.mode==='upgrades'){let removed=0;for(const b of own(p).filter(b=>b.type==='location')){const a=s.assets[b.id],n=Math.min(a.level,e.levels);removed+=n;a.level-=n;}pay(e.compensation);finish('Lost '+removed+' upgrade level(s); collected £'+e.compensation+'.');}
  else if(e.mode==='seize'){const lost=[];for(let i=0;i<e.count;i++){const b=choose(own(p).filter(fits));if(!b)break;lost.push(b.name);move(b,null);}if(lost.length)finish('Bank seized '+lost.join(' and ')+'.');else{const paid=money(s,p,-e.fallback,now,null,'advent');finish('No eligible asset: paid £'+paid+'.');}}
  else if(e.mode==='rolls'){p.rolls=0;p.campaignRolls=[];pay(e.cash);finish('All rolls lost; collected £'+e.cash+'.');}
  else{sendBreak(s,p,now);const paid=money(s,p,-e.fine,now,null,'advent');finish('Sent to Break; paid £'+paid+'.');}
 }
 else throw Error('Unknown Advent effect');
}
