create extension if not exists pgcrypto with schema extensions;
create table public.peak_state(id boolean primary key default true check(id), version bigint not null default 0, state jsonb not null);
create table public.peak_accounts(id text primary key, name text not null, pin_hash text not null, admin boolean not null default false, active boolean not null default true, failures integer not null default 0, locked_until timestamptz);
create unique index peak_account_names on public.peak_accounts(lower(name));
create table public.peak_sessions(token_hash text primary key, player text references public.peak_accounts(id), expires timestamptz not null);
create index peak_sessions_player_idx on public.peak_sessions(player);
create table public.peak_requests(id uuid primary key, player text not null, result jsonb not null, created timestamptz not null default now());
create table public.peak_audit(version bigint primary key, player text, action text not null, request uuid, details jsonb, created timestamptz not null default now());
create table public.peak_login_limits(bucket text primary key, attempts int not null, since timestamptz not null);
alter table public.peak_state enable row level security;
alter table public.peak_accounts enable row level security;
alter table public.peak_sessions enable row level security;
alter table public.peak_requests enable row level security;
alter table public.peak_audit enable row level security;
alter table public.peak_login_limits enable row level security;
revoke all on public.peak_state,public.peak_accounts,public.peak_sessions,public.peak_requests,public.peak_audit,public.peak_login_limits from anon,authenticated;
grant all on public.peak_state,public.peak_accounts,public.peak_sessions,public.peak_requests,public.peak_audit,public.peak_login_limits to service_role;
-- Only the Edge Function's service role can call these functions. No client RPCs.
create function public.peak_login(p_name text,p_pin text,p_ip text) returns jsonb language plpgsql security invoker set search_path='' as $$
declare a public.peak_accounts; tok text; lim public.peak_login_limits;
begin
 insert into public.peak_login_limits values(p_ip,1,now()) on conflict(bucket) do update set attempts=case when public.peak_login_limits.since<now()-interval '15 minutes' then 1 else public.peak_login_limits.attempts+1 end,since=case when public.peak_login_limits.since<now()-interval '15 minutes' then now() else public.peak_login_limits.since end returning * into lim;
 if lim.attempts>40 then return jsonb_build_object('error','Too many attempts. Try again in 15 minutes.'); end if;
 select * into a from public.peak_accounts where lower(name)=lower(trim(p_name)) for update;
 if a.id is null or not a.active or a.locked_until>now() then return jsonb_build_object('error','Login unavailable. Check your details or try later.'); end if;
 if extensions.crypt(p_pin,a.pin_hash)<>a.pin_hash then
 update public.peak_accounts set failures=failures+1,locked_until=case when failures+1>=5 then now()+interval '15 minutes' else null end where id=a.id;
 return jsonb_build_object('error','Login unavailable. Check your details or try later.'); end if;
 update public.peak_accounts set failures=0,locked_until=null where id=a.id;
 tok=encode(extensions.gen_random_bytes(32),'hex');
 insert into public.peak_sessions values(encode(extensions.digest(tok,'sha256'),'hex'),a.id,now()+interval '30 days');
 return jsonb_build_object('token',tok,'player',a.id,'admin',a.admin);
end $$;
create function public.peak_auth(p_token text) returns jsonb language sql security invoker set search_path='' as $$
 select jsonb_build_object('player',a.id,'admin',a.admin) from public.peak_sessions s join public.peak_accounts a on a.id=s.player where s.token_hash=encode(extensions.digest(p_token,'sha256'),'hex') and s.expires>now() and a.active;
$$;
create table public.peak_join_requests (
 id uuid primary key, name text not null check(length(name) between 1 and 60),
 token text not null, pin_hash text not null,
 status text not null default 'pending' check(status in ('pending','approved','rejected')),
 created timestamptz not null default now(), reviewed timestamptz, reviewed_by text
);
create unique index peak_pending_join_name on public.peak_join_requests(lower(name)) where status='pending';
alter table public.peak_join_requests enable row level security;
revoke all on public.peak_join_requests from anon,authenticated;
grant all on public.peak_join_requests to service_role;
create function public.peak_signup(p_id uuid,p_name text,p_pin text,p_token text,p_ip text) returns jsonb language plpgsql security invoker set search_path='' as $$
declare lim public.peak_login_limits;
begin
 perform pg_advisory_xact_lock(732198);
 if exists(select 1 from public.peak_join_requests where id=p_id) then return '{"ok":true}'::jsonb; end if;
 if length(trim(p_name)) not between 1 and 60 or p_pin !~ '^[0-9]{4}$' then return '{"error":"Choose a name and a four-digit PIN."}'::jsonb; end if;
 insert into public.peak_login_limits values('join:'||p_ip,1,now()) on conflict(bucket) do update set attempts=case when public.peak_login_limits.since<now()-interval '1 hour' then 1 else public.peak_login_limits.attempts+1 end,since=case when public.peak_login_limits.since<now()-interval '1 hour' then now() else public.peak_login_limits.since end returning * into lim;
 if lim.attempts>5 then return '{"error":"Too many requests. Try again in an hour."}'::jsonb; end if;
 if exists(select 1 from public.peak_accounts where lower(name)=lower(trim(p_name))) or exists(select 1 from public.peak_join_requests where lower(name)=lower(trim(p_name)) and status='pending') then return '{"error":"That name is already registered or waiting for approval."}'::jsonb; end if;
 if (select count(*) from public.peak_join_requests where status='pending')>=100 then return '{"error":"Requests are full. Please contact Admin."}'::jsonb; end if;
 insert into public.peak_join_requests(id,name,token,pin_hash) values(p_id,trim(p_name),p_token,extensions.crypt(p_pin,extensions.gen_salt('bf',12)));
 return '{"ok":true}'::jsonb;
end $$;
revoke all on function public.peak_signup(uuid,text,text,text,text) from public,anon,authenticated;
grant execute on function public.peak_signup(uuid,text,text,text,text) to service_role;

create function public.peak_commit(p_version bigint,p_state jsonb,p_player text,p_action text,p_request uuid,p_result jsonb,p_credentials jsonb default null) returns jsonb language plpgsql security invoker set search_path='' as $$
declare v bigint; prior jsonb; join_row public.peak_join_requests;
begin
 select version into v from public.peak_state where id=true for update;
 select result into prior from public.peak_requests where id=p_request;
 if prior is not null then return jsonb_build_object('duplicate',prior); end if;
 if v<>p_version then return jsonb_build_object('retry',true); end if;
 if p_credentials is not null then
 if p_credentials->>'kind'='add' then
 insert into public.peak_accounts(id,name,pin_hash,admin) values(p_credentials->>'id',p_credentials->>'name',extensions.crypt(p_credentials->>'pin',extensions.gen_salt('bf',12)),false);
 elsif p_credentials->>'kind' in ('approve','reject') then
 select * into join_row from public.peak_join_requests where id=(p_credentials->>'join')::uuid and status='pending' for update;
 if join_row.id is null then raise exception 'Join request already reviewed'; end if;
 if p_credentials->>'kind'='approve' then
 insert into public.peak_accounts(id,name,pin_hash,admin) values(join_row.id::text,join_row.name,join_row.pin_hash,false);
 end if;
 update public.peak_join_requests set status=case when p_credentials->>'kind'='approve' then 'approved' else 'rejected' end,reviewed=now(),reviewed_by=p_player where id=join_row.id;
 elsif p_credentials->>'kind'='reset' then
 update public.peak_accounts set pin_hash=extensions.crypt(p_credentials->>'pin',extensions.gen_salt('bf',12)),failures=0,locked_until=null where id=p_credentials->>'id';
 delete from public.peak_sessions where player=p_credentials->>'id';
 end if;end if;
 update public.peak_accounts a set active=coalesce((p_state->'players'->a.id->>'active')::boolean,a.active) where p_state->'players' ? a.id;
 delete from public.peak_sessions where player in (select id from public.peak_accounts where not active);
 update public.peak_state set state=p_state,version=v+1 where id=true;
 insert into public.peak_audit values(v+1,p_player,p_action,p_request,p_result,now());
 insert into public.peak_requests(id,player,result) values(p_request,p_player,p_result);
 return jsonb_build_object('ok',true);
end $$;
revoke all on function public.peak_login(text,text,text),public.peak_auth(text),public.peak_commit(bigint,jsonb,text,text,uuid,jsonb,jsonb) from public,anon,authenticated;
grant execute on function public.peak_login(text,text,text),public.peak_auth(text),public.peak_commit(bigint,jsonb,text,text,uuid,jsonb,jsonb) to service_role;
