-- Webhook is held in encrypted Vault, never in game state or browser responses.
create table if not exists public.peak_slack_outbox (
 id text primary key, text text not null, actor text not null, status text not null default 'pending',
 created timestamptz not null default now(), updated timestamptz not null default now(), retry_at timestamptz not null default now(), detail text
);
alter table public.peak_slack_outbox enable row level security;
revoke all on public.peak_slack_outbox from public,anon,authenticated;
grant all on public.peak_slack_outbox to service_role;
create or replace function public.peak_slack_webhook() returns text language sql security invoker set search_path='' as $$
 select decrypted_secret from vault.decrypted_secrets where name='peakopoly_slack' limit 1;
$$;
create or replace function public.peak_slack_enqueue(p_id text,p_text text,p_actor text) returns void language sql security invoker set search_path='' as $$
 insert into public.peak_slack_outbox(id,text,actor) values(p_id,p_text,p_actor) on conflict(id) do nothing;
$$;
create or replace function public.peak_slack_claim() returns setof public.peak_slack_outbox language sql security invoker set search_path='' as $$
 update public.peak_slack_outbox set status='sending',updated=now() where id in
 (select id from public.peak_slack_outbox where status='pending' and retry_at<=now() and created>now()-interval '24 hours' order by created limit 1 for update skip locked) returning *;
$$;
revoke all on function public.peak_slack_webhook(),public.peak_slack_enqueue(text,text,text),public.peak_slack_claim() from public,anon,authenticated;
grant execute on function public.peak_slack_webhook(),public.peak_slack_enqueue(text,text,text),public.peak_slack_claim() to service_role;
