create extension if not exists pg_net with schema extensions;
create extension if not exists pg_cron;
select vault.create_secret(encode(extensions.gen_random_bytes(32),'hex'),'peakopoly_cron');
create function public.peak_cron_auth(p_secret text) returns boolean language sql security invoker set search_path='' as $$
 select exists(select 1 from vault.decrypted_secrets where name='peakopoly_cron' and decrypted_secret=p_secret);
$$;
revoke all on function public.peak_cron_auth(text) from public,anon,authenticated;
grant execute on function public.peak_cron_auth(text) to service_role;
select cron.schedule('peakopoly-clock','* * * * *',$job$
 select net.http_post(url:='https://vcyfkdelmgowmhfffjgq.supabase.co/functions/v1/peakopoly',headers:='{"Content-Type":"application/json"}'::jsonb,body:=jsonb_build_object('action','scheduled','args',jsonb_build_object('secret',(select decrypted_secret from vault.decrypted_secrets where name='peakopoly_cron'))));
$job$);
select cron.schedule('peakopoly-cleanup','15 3 * * *',$job$
 delete from public.peak_sessions where expires<now();
 delete from public.peak_login_limits where since<now()-interval '1 day';
 delete from public.peak_requests where created<now()-interval '7 days';
$job$);
