create table public.peak_join_requests (
 id uuid primary key, name text not null check(length(name) between 1 and 60),
 token text not null, pin_hash text not null,
 status text not null default 'pending' check(status in ('pending','approved','rejected')),
 created timestamptz not null default now(), reviewed timestamptz, reviewed_by text
);
create unique index peak_pending_join_name on public.peak_join_requests(lower(name)) where status='pending';
alter table public.peak_join_requests enable row level security;
revoke all on public.peak_join_requests from anon,authenticated;
grant all on public.peak_join_requests to service_role;
create function public.peak_signup(p_id uuid,p_name text,p_pin text,p_token text,p_ip text) returns jsonb language plpgsql security invoker set search_path='' as $$
declare lim public.peak_login_limits;
begin
 perform pg_advisory_xact_lock(732198);
 if exists(select 1 from public.peak_join_requests where id=p_id) then return '{"ok":true}'::jsonb; end if;
 if length(trim(p_name)) not between 1 and 60 or p_pin !~ '^[0-9]{4}$' then return '{"error":"Choose a name and a four-digit PIN."}'::jsonb; end if;
 insert into public.peak_login_limits values('join:'||p_ip,1,now()) on conflict(bucket) do update set attempts=case when public.peak_login_limits.since<now()-interval '1 hour' then 1 else public.peak_login_limits.attempts+1 end,since=case when public.peak_login_limits.since<now()-interval '1 hour' then now() else public.peak_login_limits.since end returning * into lim;
 if lim.attempts>5 then return '{"error":"Too many requests. Try again in an hour."}'::jsonb; end if;
 if exists(select 1 from public.peak_accounts where lower(name)=lower(trim(p_name))) or exists(select 1 from public.peak_join_requests where lower(name)=lower(trim(p_name)) and status='pending') then return '{"error":"That name is already registered or waiting for approval."}'::jsonb; end if;
 if (select count(*) from public.peak_join_requests where status='pending')>=100 then return '{"error":"Requests are full. Please contact Admin."}'::jsonb; end if;
 insert into public.peak_join_requests(id,name,token,pin_hash) values(p_id,trim(p_name),p_token,extensions.crypt(p_pin,extensions.gen_salt('bf',12)));
 return '{"ok":true}'::jsonb;
end $$;
revoke all on function public.peak_signup(uuid,text,text,text,text) from public,anon,authenticated;
grant execute on function public.peak_signup(uuid,text,text,text,text) to service_role;
