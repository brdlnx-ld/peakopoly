import test from 'node:test';
import assert from 'node:assert/strict';
import {initial,player,apply,publicState} from '../server/engine.mjs';
import {cyberLaunch} from '../server/cyberarcade.mjs';
const pre=cyberLaunch-86400000,now=cyberLaunch+1000;
function game(t=now){const s=initial(t,()=>0);s.status='running';s.started=true;s.players.a=player('a','Amy');s.players.b=player('b','Ben');s.players.admin={...player('admin','Admin'),observer:true};s.miniConfig={enabled:true};return s;}
function run(s,action,args={},id='a',t=now,rng=()=>0){return apply(s,id,action,args,t,rng,id==='admin');}
function step(s,action,args={},id='a',t=now){const g=s.players[id].mini.session;return run(s,action,{session:g.id,seq:g.seq,...args},id,t);}
test('new arcade is date gated and old daily attempts expire at London midnight',()=>{
 const s=game(pre);assert.throws(()=>run(s,'mini_start',{game:'parcel'},'a',pre),/current arcade/);
 run(s,'mini_start',{game:'forecast'},'a',pre);
 const expired=s.players.a.mini.session;assert.throws(()=>run(s,'mini_collect',{session:expired.id,seq:expired.seq}),/No active session/);
 assert.throws(()=>run(s,'mini_start',{game:'wheel'}),/current arcade/);
 run(s,'mini_start',{game:'parcel'});
});
test('Parcel Panic rejects forged/stale moves, validates deadlines and daily caps',()=>{
 const s=game();run(s,'mini_start',{game:'parcel'});
 assert.throws(()=>step(s,'mini_sort',{lane:9}),/lane/);
 const g=s.players.a.mini.session,old={id:g.id,seq:g.seq};
 step(s,'mini_sort',{lane:0,cash:999999,score:999999});
 assert.equal(g.correct,1);assert.equal(s.players.a.cash,1200);
 assert.throws(()=>run(s,'mini_sort',{lane:0,session:old.id,seq:old.seq}),/changed/);
 step(s,'mini_sort',{lane:0},'a',now+20000);assert.equal(g.lives,2);
 step(s,'mini_collect',{},'a',now+20001);assert.equal(s.players.a.cash,1203);
 assert.throws(()=>run(s,'mini_start',{game:'parcel'}),/Already/);
});
test('Scanner Memory viewing time, private recall sequence, rewards and loss',()=>{
 const s=game();run(s,'mini_start',{game:'memory'});
 assert.throws(()=>step(s,'mini_recall'),/complete sequence/);
 step(s,'mini_recall',{},'a',now+4000);
 assert.equal(publicState(s,'a').players.a.mini.session.pattern,undefined);
 for(let i=0;i<3;i++)step(s,'mini_memory',{pad:0},'a',now+4100+i);
 assert.equal(s.players.a.mini.session.completed,1);
 step(s,'mini_recall',{},'a',now+10000);
 step(s,'mini_memory',{pad:1},'a',now+10001);
 assert.equal(s.players.a.cash,1210);assert.equal(s.players.a.mini.session,null);
});
test('Deal cages stay private, offers and final swaps derive from server values',()=>{
 const s=game();run(s,'mini_start',{game:'deal'});
 const g=s.players.a.mini.session;assert.equal(publicState(s,'a').players.a.mini.session.boxes,undefined);
 assert.equal(publicState(s,'b').players.a.mini,undefined);
 step(s,'mini_cage',{box:0});step(s,'mini_cage',{box:1});step(s,'mini_cage',{box:2});
 assert.equal(g.stage,'offer');
 assert.throws(()=>step(s,'mini_collect'),/offer/);
 step(s,'mini_cage',{box:0,choice:'risk'});step(s,'mini_cage',{box:3});step(s,'mini_cage',{box:4});
 step(s,'mini_cage',{box:0,choice:'risk'});assert.equal(g.stage,'final');
 const expected=g.boxes[5];step(s,'mini_cage',{box:5});
 assert.equal(s.players.a.cash,1200+expected);
});
test('Admin can practice every new game repeatedly before launch without economic, campaign or public feed effects',()=>{
 const s=game(pre);s.miniConfig.enabled=false;s.status='paused';
 const before=JSON.stringify({cash:s.players.admin.cash,rolls:s.players.admin.rolls,stats:s.players.admin.stats,feed:s.feed});
 for(let attempt=0;attempt<2;attempt++)for(const kind of ['parcel','memory','deal']){
  run(s,'mini_start',{game:kind},'admin',pre);
  if(kind==='parcel'){step(s,'mini_sort',{lane:0},'admin',pre);step(s,'mini_collect',{},'admin',pre);}
  if(kind==='memory'){step(s,'mini_recall',{},'admin',pre+4000);step(s,'mini_memory',{pad:1},'admin',pre+4001);}
  if(kind==='deal'){step(s,'mini_cage',{box:0},'admin',pre);step(s,'mini_cage',{box:1},'admin',pre);step(s,'mini_cage',{box:2},'admin',pre);step(s,'mini_cage',{box:0,choice:'take'},'admin',pre);}
 }
 assert.equal(JSON.stringify({cash:s.players.admin.cash,rolls:s.players.admin.rolls,stats:s.players.admin.stats,feed:s.feed}),before);
 assert.equal(s.players.admin.mini.cash,0);assert.equal(s.players.admin.mini.last.practice,true);
 assert.throws(()=>run(s,'mini_start',{game:'parcel',practice:true},'a',pre),/closed/);
});
