import assert from 'node:assert/strict';import {readFileSync,writeFileSync} from 'node:fs';
const url='https://vcyfkdelmgowmhfffjgq.supabase.co/functions/v1/peakopoly';
async function call(action,args={},token='',request=crypto.randomUUID()){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','x-session':token},body:JSON.stringify({action,args,request}),signal:AbortSignal.timeout(20000)});return {status:r.status,data:await r.json()};}
const password=readFileSync('/workspace/scratch/61efe8f85f1f/Peakopoly_Admin_Access.md','utf8').match(/Admin password: `([^`]+)`/)[1];
const admin=(await call('login',{name:'Admin',pin:password})).data;assert.ok(admin.token);const amy=(await call('login',{name:'Demo Amy',pin:'1111'})).data;assert.ok(amy.token);
const id=crypto.randomUUID(),id2=crypto.randomUUID(),name='QA Join '+id.slice(0,8),name2='QA Reject '+id2.slice(0,8);writeFileSync('/workspace/scratch/61efe8f85f1f/signup-test-ids.json',JSON.stringify({id,id2}));
assert.equal((await call('signup',{name,token:'🚚',pin:'111'},'',crypto.randomUUID())).status,400);
let r=await call('signup',{name,token:'🚚',pin:'1357'},'',id);assert.equal(r.status,200,JSON.stringify(r.data));assert.equal((await call('signup',{name,token:'🚚',pin:'1357'},'',id)).status,200,'idempotent signup');assert.equal((await call('login',{name,pin:'1357'})).status,401,'pending account cannot log in');
assert.equal((await call('admin_joins',{},amy.token)).status,400);assert.equal((await call('admin_approve',{join:id},amy.token)).status,400);
r=await call('admin_joins',{},admin.token);assert.ok(r.data.some(j=>j.id===id));assert.ok(r.data.every(j=>!('pin_hash' in j)&&!('pin' in j)));
const req=crypto.randomUUID();r=await call('admin_approve',{join:id},admin.token,req);assert.equal(r.status,200,JSON.stringify(r.data));assert.equal(r.data.state.players[id].cash,1200);assert.equal(r.data.state.players[id].rolls,1);assert.equal(r.data.state.players[id].token,'🚚');assert.equal((await call('admin_approve',{join:id},admin.token,req)).status,200,'idempotent approval');assert.equal((await call('admin_approve',{join:id},admin.token)).status,400,'second approval blocked');
const newLogin=(await call('login',{name,pin:'1357'})).data;assert.ok(newLogin.token,'chosen PIN retained');await call('logout',{},newLogin.token);
assert.equal((await call('signup',{name:name2,token:'📦',pin:'2468'},'',id2)).status,200);assert.equal((await call('admin_reject',{join:id2},admin.token)).status,200);assert.equal((await call('login',{name:name2,pin:'2468'})).status,401,'rejected account unavailable');
await call('admin_active',{player:id,active:false,reason:'Deactivate QA join test account'},admin.token);await call('logout',{},admin.token);await call('logout',{},amy.token);
console.log('PASS: validation, pending login denied, private PIN hashes, admin-only approval, idempotency, starting state, chosen PIN, rejection and deactivation.');
