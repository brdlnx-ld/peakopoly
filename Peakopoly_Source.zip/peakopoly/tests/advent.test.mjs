import test from 'node:test';
import assert from 'node:assert/strict';
import {initial,player,tick,apply,publicState,board} from '../server/engine.mjs';
import {adventCards,adventStart,adventEnd,closingStart} from '../server/adventdeck.mjs';
import {adventView,adventPending} from '../server/advent.mjs';
const now=adventStart+1000,zero=()=>0;
function fixture(t=now,rich=true){
 const s=initial(t,zero);s.status='running';s.started=true;s.campaigns={enabled:true,liquidation:{entries:{}}};
 for(let i=0;i<13;i++){const p=s.players['p'+i]=player('p'+i,'Player '+i);p.cash=rich?600+i*100:0;p.rolls=5;}
 s.players.admin={...player('admin','Admin'),observer:true};
 if(rich)board.filter(b=>b.price).forEach((b,i)=>Object.assign(s.assets[b.id],{owner:'p'+i%13,level:b.type==='location'?i%4:0,open:true}));
 return s;
}
function assign(s,c){s.campaigns.advent={hands:{p0:[{day:1,id:c.id,status:'sealed'}]}};}
function open(s,id='p0',day=1,t=now){return apply(s,id,'advent_open',{day},t,zero);}
test('312 unique identifiers, titles and effects, with 286 main and 26 closing cards',()=>{
 assert.equal(adventCards.length,312);
 for(const key of ['id','title'])assert.equal(new Set(adventCards.map(c=>c[key])).size,312);
 assert.equal(new Set(adventCards.map(c=>JSON.stringify(c.effect))).size,312);
 assert.equal(adventCards.filter(c=>c.closing).length,26);
 assert.equal(adventCards.filter(c=>c.effect.mode==='liquidate').length,1);
});
test('all 312 cards resolve on both occupied and empty boards, never create debt or invalid ownership',()=>{
 for(const rich of [true,false])for(const c of adventCards){
  const s=fixture(now,rich);assign(s,c);
  open(s);
  if(c.effect.type==='gamble')apply(s,'p0','advent_choose',{day:1,choice:'risk'},now,()=>1);
  assert.equal(s.campaigns.advent.hands.p0[0].status,'done',c.id);
  for(const p of Object.values(s.players))assert.ok(Number.isSafeInteger(p.cash)&&p.cash>=0,c.id);
  for(const [id,a] of Object.entries(s.assets)){
   assert.ok(!a.owner||s.players[a.owner],c.id);assert.ok(a.level>=0&&a.level<=3,c.id);
   if(board[id].type==='role')assert.equal(a.level,0,c.id);
  }
  assert.equal(s.undo,null);
 }
});
test('one immutable random deal, no duplicates across all players or days, no future assignment leakage',()=>{
 const s=fixture();tick(s,now);
 const deal=s.campaigns.advent;
 assert.equal(Object.keys(deal.hands).length,13);
 const rows=Object.values(deal.hands).flat();
 assert.equal(new Set(rows.map(x=>x.id)).size,312);
 assert.ok(rows.every(x=>adventCards.find(c=>c.id===x.id).closing===(x.day>=23)));
 tick(s,now+1000);assert.equal(s.campaigns.advent,deal);
 const view=adventView(s,s.players.p0,now);
 assert.equal(view.doors.length,24);assert.equal(view.doors[0].card,undefined);
 assert.equal(view.doors[1].ready,false);
 const out=publicState(s,'p0');assert.equal(out.campaigns,undefined);assert.equal(out.adventCatalogue,undefined);
 assert.ok(!JSON.stringify(out).includes('"hands"'));
});
test('missed days open oldest first; choice stays pending, stale requests and future days rejected',()=>{
 const s=fixture();s.campaigns.advent={hands:{p0:[{day:1,id:'gamble-01',status:'sealed'},{day:2,id:'windfall-01',status:'sealed'}]}};
 assert.throws(()=>open(s,'p0',2),/oldest/);
 assert.throws(()=>apply(s,'p0','roll',{},now,zero),/oldest Advent/);
 assert.throws(()=>apply(s,'p0','advent_choose',{day:1,choice:'safe'},now,zero),/Reveal/);
 open(s);assert.equal(adventPending(s,s.players.p0,now).status,'choice');
 apply(s,'p0','advent_choose',{day:1,choice:'safe'},now,zero);
 assert.throws(()=>open(s,'p0',2),/No Advent/);
 open(s,'p0',2,now+86400000);
 assert.throws(()=>open(s,'p0',2,now+86400000),/No Advent/);
});
test('liquidation cancels affected offers; closing protection prevents late portfolio wipes',()=>{
 const s=fixture();assign(s,adventCards.find(c=>c.effect.mode==='liquidate'));
 const owned=Object.entries(s.assets).find(([,a])=>a.owner==='p0')[0];
 s.trades=[{id:'x',from:'p0',to:'p1',give:[Number(owned)],want:[],expires:adventEnd,status:'pending'}];
 open(s);assert.equal(s.trades[0].status,'cancelled');
 assert.equal(s.players.p0.cash,0);assert.equal(s.players.p0.position,10);assert.equal(s.players.p0.active,true);
 const late=fixture(closingStart);assign(late,adventCards.find(c=>c.effect.mode==='liquidate'));
 const assets=structuredClone(late.assets),cash=late.players.p0.cash;
 open(late,'p0',1,closingStart);assert.deepEqual(late.assets,assets);assert.equal(late.players.p0.cash,cash+50);
});
test('Admin laboratory cannot mutate live holdings, feed or actual card assignments',()=>{
 const s=fixture();tick(s,now);
 const before=JSON.stringify(s),events=apply(s,'admin','admin_advent_preview',{player:'p0',card:'disaster-01'},now,zero,true).events;
 assert.equal(JSON.stringify(s),before);assert.equal(events[0].after.cash,0);assert.equal(events[0].before.cash,600);
 assert.throws(()=>apply(s,'p0','admin_advent_preview',{card:'windfall-01'},now,zero),/Admin required/);
});
test('roster mismatch blocks draw and finale expires unopened envelopes',()=>{
 const s=fixture();s.players.p12.active=false;tick(s,now);assert.equal(s.campaigns.advent,undefined);
 s.players.p12.active=true;tick(s,now);assert.ok(s.campaigns.advent);
 assert.equal(adventPending(s,s.players.p0,adventEnd),null);
 assert.throws(()=>open(s,'p0',1,adventEnd),/No Advent/);
});
