import test from 'node:test';
import assert from 'node:assert/strict';
import {apply,initial,player,publicState} from '../server/engine.mjs';
import {scheduledMessages,slackPayload,weeklyText} from '../server/slack.mjs';

const at=Date.parse('2026-11-11T19:00:00Z'),rng=()=>0;
const game=()=>{const s=initial(at,rng);s.status='running';s.started=true;s.players.a=player('a','Amy');s.players.b=player('b','Ben');return s;};

test('Wanted accepts two distinct locations, rejects roles and owned property, and clears acquired wishes',()=>{
 const s=game(),applyAs=(p,action,args)=>apply(s,p,action,args,at,rng);
 s.assets[1].owner='b';s.assets[3].owner='a';
 const want=(asset,open=true)=>applyAs('a','wanted',{asset,open});
 want(1);want(1);want(5);
 assert.deepEqual(publicState(s,'b').players.a.wanted,[1,5]);
 assert.throws(()=>want(6),/two slots/);
 assert.throws(()=>want(4),/location|property/i);
 assert.throws(()=>want(3),/already own/);
 want(5,false);want(6);
 applyAs('b','offer',{to:'a',give:[1],want:[],giveCash:0,wantCash:10});
 assert.deepEqual(s.players.a.wanted,[1,6]);
 applyAs('a','accept',{trade:s.trades[0].id});
 assert.equal(s.assets[1].owner,'a');
 assert.deepEqual(s.players.a.wanted,[6]);
 s.players.a.pending=6;
 applyAs('a','buy',{});
 assert.deepEqual(publicState(s,'b').players.a.wanted,[]);
});

test('Wednesday Trade Desk is included only in the normal Rent Wars daily Slack report',()=>{
 const s=game();
 s.campaigns={enabled:true};
 s.slackConfig={enabled:true,dailyTime:'19:00',reset:false,weekly:false};
 const messages=scheduledMessages(s,at);
 assert.equal(messages.length,1);
 assert.equal(messages[0].id,'daily:2026-11-11');
 assert.match(messages[0].text,/Wednesday Trade Desk/);
 assert.equal(scheduledMessages(s,at+60000)[0].id,messages[0].id);
 assert.doesNotMatch(scheduledMessages(s,at+86400000)[0].text,/Wednesday Trade Desk/);
 const payload=slackPayload(messages[0].text);
 assert.equal(payload.text.match(/<!channel>/g).length,1);
 assert.equal(payload.blocks[1].type,'image');
 s.campaigns.enabled=false;
 assert.doesNotMatch(scheduledMessages(s,at)[0].text,/Wednesday Trade Desk/);
});

test('Mascot awards report tied winners and skip zero scores',()=>{
 const a={name:'Amy',trades:2,rent:90,breaks:0},b={name:'Ben',trades:2,rent:10,breaks:0};
 const body=weeklyText({rows:[a,b],awards:{rent:a,trades:a,breaks:a}});
 assert.match(body,/Deal Maker\*: Amy, Ben · 2 completed trades/);
 assert.match(body,/Rent Collector\*: Amy · £90/);
 assert.match(body,/Most Trips to Break\*: no winner/);
});
