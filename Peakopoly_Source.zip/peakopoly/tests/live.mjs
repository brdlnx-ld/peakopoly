// Run against the dedicated dummy-player instance only.
import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
const url='https://vcyfkdelmgowmhfffjgq.supabase.co/functions/v1/peakopoly';
async function call(action,args={},token='',request=crypto.randomUUID()){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','x-session':token},body:JSON.stringify({action,args,request})});return {status:r.status,data:await r.json()};}
const pwd=readFileSync('/workspace/scratch/61efe8f85f1f/Peakopoly_Admin_Access.md','utf8').match(/Admin password: `([^`]+)`/)[1];
const admin=(await call('login',{name:'Admin',pin:pwd})).data;assert.ok(admin.token,'admin login');const amy=(await call('login',{name:'Demo Amy',pin:'1111'})).data;const ben=(await call('login',{name:'Demo Ben',pin:'2222'})).data;assert.ok(amy.token,'PIN login');assert.ok(ben.token);
assert.equal((await call('read')).status,401,'unauthenticated state blocked');assert.equal((await call('admin_cash',{player:'dummy-amy',amount:100},amy.token)).status,400,'admin blocked for player');
let r=await call('admin_status',{status:'running',reason:'Automated dummy-player verification'},admin.token);assert.equal(r.status,200,JSON.stringify(r.data));
const req=crypto.randomUUID();r=await call('admin_cash',{player:'dummy-amy',amount:100,reason:'Idempotency test'},admin.token,req);assert.equal(r.data.state.players['dummy-amy'].cash,1300);r=await call('admin_cash',{player:'dummy-amy',amount:100},admin.token,req);assert.equal(r.data.state.players['dummy-amy'].cash,1300,'duplicate action applied once');
r=await call('read',{},amy.token);assert.equal(r.data.state.decks,undefined);assert.equal(r.data.state.players['dummy-ben'].notifications,undefined);assert.equal(r.data.state.rollHistory,undefined);const rev=r.data.state.revision;
assert.equal((await call('admin_undo',{version:rev-1},admin.token)).status,400,'stale undo refused');r=await call('admin_undo',{version:rev},admin.token);assert.equal(r.status,200,JSON.stringify(r.data));assert.equal(r.data.state.players['dummy-amy'].cash,1200);
// Grant rolls concurrently, each request must be applied exactly once.
await Promise.all([call('admin_rolls',{player:'dummy-amy',amount:1},admin.token),call('admin_rolls',{player:'dummy-amy',amount:1},admin.token)]);r=await call('read',{},amy.token);assert.equal(r.data.state.players['dummy-amy'].rolls,3,'CAS prevents lost updates');
r=await call('roll',{},amy.token);assert.equal(r.status,200,JSON.stringify(r.data));assert.ok(r.data.events.some(e=>e.type==='dice'));assert.ok(r.data.state.players['dummy-amy'].position>=0);assert.equal(r.data.state.players['dummy-amy'].stats.rollsUsed,1);if(r.data.state.players['dummy-amy'].pending!==null){r=await call('buy',{},amy.token);assert.equal(r.status,200,JSON.stringify(r.data));}
const offer=await call('offer',{to:'dummy-ben',give:[],want:[],giveCash:10,wantCash:0},amy.token);assert.equal(offer.status,200,JSON.stringify(offer.data));const trade=offer.data.state.trades[0];r=await call('accept',{trade:trade.id},ben.token);assert.equal(r.status,200,JSON.stringify(r.data));assert.equal(r.data.state.players['dummy-ben'].stats.tradesCompleted,1);
// PIN lockout persisted even though login fails.
for(let i=0;i<5;i++)assert.equal((await call('login',{name:'Demo Sam',pin:'9999'})).status,401);assert.equal((await call('login',{name:'Demo Sam',pin:'4444'})).status,401);
r=await call('admin_pin',{player:'dummy-sam',pin:'4444',reason:'Restore dummy after lockout test'},admin.token);assert.equal(r.status,200,JSON.stringify(r.data));assert.ok((await call('login',{name:'Demo Sam',pin:'4444'})).data.token);
assert.equal((await call('logout',{},amy.token)).status,200);assert.equal((await call('read',{},amy.token)).status,401,'logout revokes token');
await call('admin_status',{status:'paused',reason:'Verification complete'},admin.token);
console.log('PASS: live PIN login, admin authorization, private state, idempotency, atomic concurrency, stale Undo, roll/purchase, trades, lockout, PIN reset and logout.');
