import test from 'node:test';
import assert from 'node:assert/strict';
import {initial,player,tick,apply,board} from '../server/engine.mjs';
import {calendar as c,recordRent,bonusRolls,campaignView} from '../server/campaigns.mjs';
import {scheduledMessages,slackPayload} from '../server/slack.mjs';
const stub=()=>0;
function game(now){
 const s=initial(now,stub);s.status='running';s.started=true;s.campaigns={enabled:true};
 for(let i=0;i<13;i++)s.players['p'+i]=player('p'+i,'Player '+i);
 s.players.admin={...player('admin','Admin'),observer:true};
 return s;
}
test('Rent Wars draws 13 unique players, counts only paid property rent and distributes exactly 50/25 once',()=>{
 const s=game(c.rentStart-1);tick(s,c.rentStart-1);assert.equal(s.campaigns.rent,undefined);
 tick(s,c.rentStart);
 const teams=s.campaigns.rent.teams;
 assert.deepEqual(teams.map(t=>t.members.length),[5,4,4]);assert.equal(new Set(teams.flatMap(t=>t.members.map(m=>m.id))).size,13);
 const m=s.players[teams[1].members[0].id], payer=s.players[teams[0].members[0].id];
 const loc=board.find(b=>b.type==='location'&&b.id>=2);s.assets[loc.id].owner=m.id;payer.position=loc.id-2;payer.cash=5;
 apply(s,payer.id,'roll',{},c.rentStart+1,stub);assert.equal(m.stats.rentEarned,5);
 assert.equal(teams[1].members[0].rent,5);
 const role=board.find(b=>b.type==='role'&&b.id>=2);s.assets[role.id].owner=m.id;payer.position=role.id-2;payer.cash=5;
 apply(s,payer.id,'roll',{},c.rentStart+2,stub);assert.equal(m.stats.skillEarned,5);assert.equal(teams[1].members[0].rent,5);
 recordRent(s,s.players[teams[0].members[0].id],500,c.rentEnd-1);
 recordRent(s,m,415,c.rentEnd-1);
 tick(s,c.rentEnd);tick(s,c.rentEnd+60000);
 assert.equal(s.campaigns.rent.final[0].name,teams[1].name);
 for(const t of s.campaigns.rent.final)assert.equal(t.members.reduce((n,x)=>n+bonusRolls(s,s.players[x.id],c.rentEnd),0),t.prize);
 m.rolls=0;m.position=0;m.pending=null;m.inBreak=false;
 const before=bonusRolls(s,m,c.rentEnd);apply(s,m.id,'roll',{},c.rentEnd+61000,stub);
 assert.equal(bonusRolls(s,m,c.rentEnd),before-1);assert.equal(bonusRolls(s,m,c.prizeEnd),0);
});
test('Black Friday applies once, to a player-selected purchase, with an exact cutoff',()=>{
 const s=game(c.saleStart),p=s.players.p0, b=board.find(b=>b.price>=300);
 p.pending=b.id;
 assert.throws(()=>apply(s,p.id,'buy',{voucher:true},c.saleStart-1),/unavailable/);
 apply(s,p.id,'buy',{voucher:true},c.saleStart);assert.equal(p.cash,1200-b.price+60);assert.equal(s.assets[b.id].owner,p.id);
 p.pending=board.find(x=>x.price&&x.id!==b.id).id;
 assert.throws(()=>apply(s,p.id,'buy',{voucher:true},c.saleStart+1),/unavailable/);
 p.campaignVoucherUsed=false;
 assert.throws(()=>apply(s,p.id,'buy',{voucher:true},c.saleEnd),/unavailable/);
});
test('Cyber Monday awards one roll for actual arcade play, not empty starts, once per player',()=>{
 const s=game(c.cyberStart),p=s.players.p0;s.miniConfig={enabled:true};
 apply(s,p.id,'mini_start',{game:'container'},c.cyberStart,stub);
 let g=p.mini.session;apply(s,p.id,'mini_collect',{session:g.id,seq:g.seq},c.cyberStart+1,stub);
 assert.equal(bonusRolls(s,p,c.cyberStart+1),0);
 apply(s,p.id,'mini_start',{game:'wheel'},c.cyberStart+2,stub);
 apply(s,p.id,'mini_start',{game:'forecast'},c.cyberStart+3,stub);
 g=p.mini.session;apply(s,p.id,'mini_guess',{guess:'higher',session:g.id,seq:g.seq},c.cyberStart+4,stub);
 assert.equal(bonusRolls(s,p,c.cyberStart+4),1);assert.equal(bonusRolls(s,p,c.cyberRollEnd),0);
});
test('Advent doors expire, cannot be reclaimed and final net worth freezes at 19:00',()=>{
 const s=game(c.adventStart),p=s.players.p0;s.endsAt=c.finale;
 assert.throws(()=>apply(s,p.id,'campaign_door',{day:1},c.adventStart-1),/locked/);
 apply(s,p.id,'campaign_door',{day:1},c.adventStart);assert.equal(p.cash,1215);
 assert.throws(()=>apply(s,p.id,'campaign_door',{day:1},c.adventStart+1),/claimed/);
 assert.throws(()=>apply(s,p.id,'campaign_door',{day:2},c.adventStart+86400000),/unfinished/);
 assert.equal(campaignView(s,p,c.finale-1).doors.at(-1).day,24);
 tick(s,c.finale);assert.equal(s.status,'ended');assert.equal(s.results.find(r=>r.id===p.id).netWorth,1215);
 assert.throws(()=>apply(s,p.id,'roll',{},c.finale),/ended/);
 assert.throws(()=>apply(s,'admin','admin_status',{status:'running'},c.finale,stub,true),/finale/);
});
test('Slack combines Rent Wars with weekly results and uses mascot and channel mention',()=>{
 const s=game(c.rentStart-1);s.slackConfig={enabled:true,weekly:true,enabledAt:c.rentStart-100000};tick(s,c.rentStart);
 const msgs=scheduledMessages(s,c.rentStart);assert.equal(msgs.length,1);
 const payload=slackPayload(msgs[0].text);assert.match(payload.text,/<!channel>/);assert.match(payload.text,/Rent Wars is live/);assert.equal(payload.blocks[1].type,'image');
 const cyber=scheduledMessages(s,c.cyberStart+9*3600000);assert.ok(cyber.some(x=>x.text.includes('Scanner Glitch')));
});
