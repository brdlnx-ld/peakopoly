import test from 'node:test';import assert from 'node:assert/strict';
import {initial,player,apply,tick,worth,publicState} from '../server/engine.mjs';
import {familyActive,familyDebt,familySkim,familyVisit} from '../server/family.mjs';
const now=Date.parse('2026-11-27T20:00:00Z'),rng=()=>0;
function fixture(){const s=initial(now,rng);s.started=true;s.status='running';for(const id of ['a','b','c'])s.players[id]=player(id,id.toUpperCase());s.players.a.cash=100;s.players.c.cash=100;s.miniConfig={enabled:true};return s;}
const run=(s,id,action,args={},at=now,r=rng)=>apply(s,id,action,args,at,r);
test('£10,000 loan has £15,000 liability; entry and single-contract rules are server enforced',()=>{
 const s=fixture();run(s,'a','family',{deal:'loan',cash:999999});
 assert.equal(s.players.a.cash,10100);assert.equal(familyDebt(s.players.a),15000);assert.equal(worth(s,s.players.a),-4900);
 assert.throws(()=>run(s,'a','family',{deal:'loan'}),/under £150|One Family/);
 assert.throws(()=>run(s,'b','family',{deal:'job'}),/under £150/);
 assert.throws(()=>run(s,'a','offer',{to:'c',give:[],want:[],giveCash:100,wantCash:0}),/blocks cash/);
});
test('75% income deductions cover actual paid rent, START and arcade; finish at exact debt',()=>{
 const s=fixture();run(s,'a','family',{deal:'loan'});s.assets[1].owner='a';
 s.players.b.position=39;run(s,'b','roll',{},now,rng);
 assert.equal(s.players.a.cash,10102);assert.equal(familyDebt(s.players.a),14992);
 s.players.a.position=38;run(s,'a','roll');
 assert.equal(s.players.a.cash,10139);assert.equal(familyDebt(s.players.a),14879);
 run(s,'a','mini_start',{game:'wheel'},now,()=>4);
 assert.equal(s.players.a.cash,10151);assert.equal(familyDebt(s.players.a),14841);
 s.players.a.family.contract.debt=1;
 const before=s.players.a.cash;s.players.a.cash+=10;
 const taken=familySkim(s,s.players.a,10,'rent',now,()=>{},()=>{});
 assert.equal(taken,1);assert.equal(s.players.a.cash,before+9);assert.equal(familyActive(s.players.a),false);
});
test('mob removes all upgrades, applies shared target protection and favours default after 72 hours',()=>{
 const s=fixture();s.assets[1]={owner:'b',level:3,open:false};s.assets[3]={owner:'b',level:2,open:false};
 run(s,'a','family',{deal:'mob',target:'b',serverSession:'a'.repeat(64)});
 assert.equal(s.assets[1].level+s.assets[3].level,0);assert.equal(s.assets[1].owner,'b');
 assert.equal(familyDebt(s.players.a),750);
 s.assets[1].level=1;
 assert.throws(()=>run(s,'c','family',{deal:'mob',target:'b'}),/72-hour/);
 const feed=()=>{},notify=()=>{};
 familyVisit(s,s.players.a,'a'.repeat(64),now,feed,notify);
 assert.equal(s.players.a.family.contract.favourCalled,undefined);
 familyVisit(s,s.players.a,'b'.repeat(64),now,feed,notify);
 assert.equal(s.players.a.family.contract.favourCalled,true);
 const view=publicState(s,'a');assert.equal(view.family.contract.favourSeen,undefined);
 assert.ok(s.players.a.family.contract.favourSeen.length>0,'projection must not mutate server sessions');
 tick(s,now+72*3600000);
 assert.equal(familyDebt(s.players.a),1000);assert.equal(s.players.a.family.contract.favour,false);
});
test('takeovers transfer upgrades, cancel pending offers and debt survives portfolio loss',()=>{
 const s=fixture();s.assets[1]={owner:'b',level:3,open:true};
 s.trades=[{id:'t',from:'b',to:'c',give:[1],want:[],giveCash:0,wantCash:0,status:'pending',expires:now+86400000}];
 run(s,'a','family',{deal:'takeover',asset:1});
 assert.equal(s.assets[1].owner,'a');assert.equal(s.assets[1].level,3);assert.equal(familyDebt(s.players.a),240);
 assert.equal(s.trades[0].status,'cancelled');
 assert.throws(()=>run(s,'a','offer',{to:'c',give:[1],want:[],giveCash:0,wantCash:0}),/blocks asset/);
 s.assets[1].owner=null;s.assets[1].level=0;s.players.a.cash=0;
 assert.equal(familyDebt(s.players.a),240);
});
test('Burn the Books clears only Family obligations, once; voluntary transfers create entry cooldown',()=>{
 const s=fixture();run(s,'a','family',{deal:'loan'});s.assets[1].owner='a';s.players.a.rolls=4;
 run(s,'a','family',{deal:'burn'});
 assert.equal(s.players.a.cash,0);assert.equal(s.assets[1].owner,null);assert.equal(s.players.a.rolls,4);assert.equal(familyActive(s.players.a),false);
 run(s,'a','family',{deal:'job'});
 assert.throws(()=>run(s,'a','family',{deal:'burn'}),/unavailable/);
 const q=fixture();run(q,'a','offer',{to:'c',give:[],want:[],giveCash:1,wantCash:0});run(q,'c','accept',{trade:q.trades[0].id});
 assert.throws(()=>run(q,'a','family',{deal:'loan'}),/voluntary transfers/);
});
test('Protection Racket covers five board rolls then seizes five positive collections',()=>{
 const s=fixture();run(s,'a','family',{deal:'racket'});
 s.assets[1].owner='b';
 for(let i=0;i<5;i++){s.players.a.position=39;s.players.a.pending=null;s.players.a.rolls=2;run(s,'a','roll');}
 assert.equal(s.players.a.family.contract.cover,0);assert.equal(s.players.a.family.contract.collections,5);
 const p=s.players.a;
 for(let i=0;i<5;i++){p.cash+=20;assert.equal(familySkim(s,p,20,'rent',now,()=>{},()=>{}),20);}
 assert.equal(familyActive(p),false);
});
test('One Last Job grants separate rolls, redirects START and preserves £500 debt',()=>{
 const s=fixture();run(s,'a','family',{deal:'job'});
 assert.equal(s.players.a.campaignRolls[0].count,15);assert.equal(familyDebt(s.players.a),1250);
 s.players.a.position=38;const cash=s.players.a.cash;run(s,'a','roll');
 assert.equal(s.players.a.cash,cash);assert.equal(s.players.a.family.contract.starts,4);
 assert.equal(s.players.a.family.contract.debt,500);
});
